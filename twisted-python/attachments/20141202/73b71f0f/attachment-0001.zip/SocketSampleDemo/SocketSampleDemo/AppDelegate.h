//
//  AppDelegate.h
//  SocketSampleDemo
//
//  Created by Sudhir Chavan on 01/12/14.
//  Copyright (c) 2014 oabstudios.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) HomeViewController *viewController;

@end

