//
//  HomeViewController.m
//  SocketSampleDemo
//
//  Created by Sudhir Chavan on 01/12/14.
//  Copyright (c) 2014 oabstudios.com. All rights reserved.
//

#import "HomeViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController
@synthesize inputStream, outputStream;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.labelForTitle.hidden = YES;
    self.viewForServerConnectingMessage.hidden = NO;
    self.buttonForGetData.hidden = YES;
}

- (void)viewWillAppear:(BOOL)animated
{
    [self initSocketNetworkCommunication];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIButton Action Methods
- (IBAction)fnForGetDataFromSocketButtonPressed:(id)sender
{
    if(self.isConnectedToServer)
    {
        self.labelForStatusMessage.text = @"Communicating with socket";
        
        NSString *response  = [NSString stringWithFormat:@"demo:"];
        NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSASCIIStringEncoding]];
        [outputStream write:[data bytes] maxLength:[data length]];
    }
    else
    {
        //NSLog(@"Join: Not connected to chat server");
    }
}

- (void)JoinSocketToFetchData
{
    if(self.isConnectedToServer)
    {
        self.labelForStatusMessage.text = @"Communicating with socket";
        
        NSString *response  = [NSString stringWithFormat:@"demo:"];
        NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSASCIIStringEncoding]];
        [outputStream write:[data bytes] maxLength:[data length]];
    }
    else
    {
        //NSLog(@"Join: Not connected to chat server");
    }
}

#pragma mark - Socket Communication
- (void)initSocketNetworkCommunication
{
    if(self.isConnectedToServer == NO)
    {
        self.labelForStatusMessage.text = @"Connecting to socket...";
        self.viewForServerConnectingMessage.hidden = NO;
        self.labelForTitle.hidden = YES;
        
        [self.timerForHostConnectivity invalidate];
        self.timerForHostConnectivity = nil;
        
        CFReadStreamRef readStream;
        CFWriteStreamRef writeStream;
        
        //Connect with socket on chat server Staging
        CFStreamCreatePairWithSocketToHost(NULL, (CFStringRef)@"54.85.59.149", 236, &readStream, &writeStream);
        
        inputStream = (__bridge NSInputStream *)readStream;
        outputStream = (__bridge NSOutputStream *)writeStream;
        [inputStream setDelegate:self];
        [outputStream setDelegate:self];
        [inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        [outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        [inputStream open];
        [outputStream open];
    }
}

- (void)removeSocketNetworkCommunication
{
    if(self.isConnectedToServer)
    {
        //stop timer and close the connection
        [self.timerForHostConnectivity invalidate];
        self.timerForHostConnectivity = nil;
        
        //close connection with chat server
        [self.inputStream close];
        [self.inputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.inputStream.delegate = nil;
        self.inputStream = nil;
        
        [self.outputStream close];
        [self.outputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.outputStream.delegate = nil;
        self.outputStream = nil;
    }
    else
    {
        //stop timer and close the connection
        [self.timerForHostConnectivity invalidate];
        self.timerForHostConnectivity = nil;
        
        [self.inputStream close];
        [self.inputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.inputStream.delegate = nil;
        self.inputStream = nil;
        
        [self.outputStream close];
        [self.outputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.outputStream.delegate = nil;
        self.outputStream = nil;
    }
    self.labelForStatusMessage.text = @"Can't connect to socket";
    self.isConnectedToServer = NO;
    self.isJoinedToInAppSocket = NO;
}

#pragma mark NSStreamEvent Delegate Methods
- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent
{
    //NSLog(@"Stream: %d", streamEvent);
    
    switch (streamEvent)
    {
        case NSStreamEventOpenCompleted:
            if([theStream isKindOfClass:[inputStream class]])
            {
                //NSLog(@"NSStreamEventOpenCompleted: Input Stream opened");
            }
            else
            {
                //NSLog(@"NSStreamEventOpenCompleted: Output Stream opened");
                self.isConnectedToServer = YES;
                
                
            }
            break;
        case NSStreamEventHasSpaceAvailable:
            //NSLog(@"NSStreamEventHasSpaceAvailable");
            if(self.isConnectedToServer)
            {
                if(self.isJoinedToInAppSocket == NO)
                {
                    self.isJoinedToInAppSocket = YES;
                    self.labelForTitle.hidden = NO;
                    self.viewForServerConnectingMessage.hidden = YES;
                    self.buttonForGetData.hidden = NO;
                    self.labelForStatusMessage.text = @"Connected";
                    //[self JoinSocketToFetchData];
                }
            }
            break;
        case NSStreamEventHasBytesAvailable:  //We need a semicolon here before we can declare local variables
            
            if (theStream == inputStream)
            {
                //NSLog(@"NSStreamEventHasBytesAvailable: Data found on stream");
                
                uint8_t buffer[10240];
                int len;
                
                while([inputStream hasBytesAvailable])
                {
                    len = [inputStream read:buffer maxLength:sizeof(buffer)];
                    NSLog(@"Length: %d", len);
                    if(len > 0)
                    {
                        NSString *stringData = [[NSString alloc] initWithBytes:buffer length:len encoding:NSASCIIStringEncoding];
                        output = [output stringByAppendingString:stringData];
                        
                        //NSLog(@"%@", output);
                    }
                    else if (len == -1)
                    {
                        output = @"";
                        break;
                    }
                    else if (len == 0)
                    {
                        //End reached
                        break;
                    }
                }
                if (output != nil && ![output isEqualToString:@""])
                {
                    //NSLog(@"server said: %@", output);
                    
                    //NSLog(@"Message received: %@", output);
                    output = @"";
                }
                else
                {
                    output = @"";
                }
                self.labelForStatusMessage.text = @"Receiving data";
            }
            break;
            
        case NSStreamEventErrorOccurred:
            //NSLog(@"NSStreamEventErrorOccurred: Can not connect to the host!");
            self.isConnectedToServer = NO;
            self.isJoinedToInAppSocket = NO;
            self.viewForServerConnectingMessage.hidden = NO;
            self.labelForTitle.hidden = YES;
            self.labelForStatusMessage.text = @"Connection failed";
            
            if(![self.timerForHostConnectivity isValid])
            {
                //[self removeSocketNetworkCommunication];
                //stop timer and close the connection
                [self.timerForHostConnectivity invalidate];
                self.timerForHostConnectivity = nil;
                
                [self.inputStream close];
                [self.inputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
                self.inputStream.delegate = nil;
                self.inputStream = nil;
                
                [self.outputStream close];
                [self.outputStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
                self.outputStream.delegate = nil;
                self.outputStream = nil;
                
                //NSLog(@"Timer started");
                self.timerForHostConnectivity = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(initSocketNetworkCommunication) userInfo:nil repeats:NO];
            }
            
            break;
            
        case NSStreamEventEndEncountered:
            //NSLog(@"NSStreamEventEndEncountered");
            [theStream close];
            [theStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
            theStream = nil;
            self.isConnectedToServer = NO;
            self.isJoinedToInAppSocket = NO;
            self.labelForStatusMessage.text = @"Connection failed";
            
            if(![self.timerForHostConnectivity isValid])
            {
                //NSLog(@"Timer started");
                self.timerForHostConnectivity = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(initSocketNetworkCommunication) userInfo:nil repeats:NO];
            }
            
            break;
            
        default:
            //NSLog(@"Unknown event");
            break;
    }
}

@end
