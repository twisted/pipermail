//
//  HomeViewController.h
//  SocketSampleDemo
//
//  Created by Sudhir Chavan on 01/12/14.
//  Copyright (c) 2014 oabstudios.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController <NSStreamDelegate>
{
    NSString *output;
}

@property (weak, nonatomic) IBOutlet UIButton *buttonForGetData;
@property (weak, nonatomic) IBOutlet UILabel *labelForTitle;
@property (weak, nonatomic) IBOutlet UILabel *labelForStatusMessage;

@property (strong, nonatomic) IBOutlet UIView *viewForServerConnectingMessage;
@property (assign, nonatomic) BOOL isConnectedToServer;
@property (assign, nonatomic) BOOL isJoinedToInAppSocket;
@property (strong, nonatomic) NSTimer *timerForHostConnectivity;
@property (nonatomic, strong) NSInputStream *inputStream;
@property (nonatomic, strong) NSOutputStream *outputStream;
- (void)initSocketNetworkCommunication;
- (void)removeSocketNetworkCommunication;

- (IBAction)fnForGetDataFromSocketButtonPressed:(id)sender;


@end
