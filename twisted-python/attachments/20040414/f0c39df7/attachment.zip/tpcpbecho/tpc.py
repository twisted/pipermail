"""
Encapsulation of TIMER hack to enable Twisted reactor and wx
event loop to play nice.
"""

from wxPython.wx import wxTimer, EVT_TIMER
from twisted.internet import reactor
from PythonCard import model

class TpcApp(model.PythonCardApp):
    def OnInit(self):
        model.PythonCardApp.OnInit(self)
        # some wxPython versions interfere with twisted's signal
        # handling -- if you have that problem, use
        # reactor.startRunning(installSignalHandlers=0)
        # otherwise, use
        # reactor.startRunning()
        reactor.startRunning(installSignalHandlers=0)
        EVT_TIMER(self,999999,self.OnTimer)
        self.timer=wxTimer(self,999999)
        self.timer.Start(250,False)
        return 1

    def OnTimer(self, event):
        reactor.runUntilCurrent()
        reactor.doIteration(0)

