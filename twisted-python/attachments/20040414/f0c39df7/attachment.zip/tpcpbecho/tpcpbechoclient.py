"""
Twisted PythonCard PbEchoClient
"""

import sys
from PythonCard import model
from tpc import TpcApp
from twisted.cred.credentials import UsernamePassword
from twisted.spread import pb
from twisted.internet import reactor

from wxPython.wx import wxTimer

from pbecho import DefinedError

class TpcPbEchoPanel(model.Background):
    """
    TPC PB Echo GUI Panel
    """
    
    def on_openBackground(self, event):
        self.pbfactory = pb.PBClientFactory()
        # KEA the Send button and SendTextField could be disabled
        # until a successful login
        self.components.SendTextField.enabled = False
        self.components.buttonSend.enabled = False

    def on_SendTextField_keyPress(self, event):
        # if user presses return, send text
        if event.keyCode == 13:
            self.sendAndClearText()
        else:
            event.skip()
        
    def on_buttonLogin_mouseClick(self, event):
        reactor.connectTCP("localhost", pb.portno, self.pbfactory)
        self.pbfactory.login(
            UsernamePassword("guest", "guest")
                ).addCallbacks(self.loginsuccess,
                               self.loginfailure)

    def loginsuccess(self, perspective):
        self.statusBar.text = 'Connected'
        self.components.SendTextField.enabled = True
        self.components.buttonSend.enabled = True
        self.perspective = perspective

    def loginfailure(self, error):
        self.displaycontent("Error on login: %s" % error)

    def sendAndClearText(self):
        fld = self.components.SendTextField
        # KEA 2004-04-12
        # should callbacks be registered everytime callRemote is called?!
        # SCW 2004-04-12
        # Yep. :)  You have to register callbacks, because you
        # are getting a "Deferred" back from the PB server --
        # you'll never get the actual values unless you register
        # the callbacks.  That's how it can be asynchronous: you
        # can do other stuff while the loop keeps checking for
        # the Deferred's values to come back ... no need for
        # threads.  Yay!  :)
        self.perspective.callRemote('echo', fld.text
            ).addCallbacks(self.echosuccess,
                           self.echofailure)
        fld.text = ""

    def on_buttonSend_mouseClick(self, event):
        self.sendAndClearText()

    def echosuccess(self, message):
        self.displaycontent(message)

    def echofailure(self, error):
        t = error.trap(DefinedError)
        self.displaycontent("error received"+t)

    def displaycontent(self, text):
        self.components.ReceivedTextArea.text += text+'\n'

    def on_menuFileExit_select(self, event):
        self.Close(True)
        reactor.stop()


if __name__ == '__main__':
    app = TpcApp(TpcPbEchoPanel)
    app.MainLoop()

