from twisted.spread import pb, jelly
import Singleton

        
class Thingy:
    def __init__(self, number="0", plant="Standard",
                 weight="24000", weight_unit="kg"):
        self.number = number
        self.plant  = plant
        self.weight = weight
        self.weight_unit = weight_unit


class Thingies:
    __metaclass__ = Singleton.Singleton

    def __init__(self):
        self.thingies = {}
      
    def getThingy(self,number):
        return self.thingies[number]

    def addThingy(self,thingy):
        self.thingies[thingy.number] = thingy
      
    def getThingyList(self,fields):
        """
        Return a tuple of a tuple of the given fields of all
        Thingies. got it?
        """
        thingyList = []
        thingyFields = []
        for t in self.thingies.keys():
            for f in fields:
               thingyFields.append(getattr(self.thingies[t],f))
            thingyList.append(thingyFields)
            thingyFields = []
        return thingyList

    def updateThingy(self,thingy):
        retval = False
        if isinstance(thingy,Thingy):
            self.thingies[thingy.number] = thingy      
            retval = True
        return retval


class CopyThingy(Thingy, pb.Copyable):
    pass

class ReceiverThingy(pb.RemoteCopy, Thingy):
    pass


pb.setUnjellyableForClass(CopyThingy,ReceiverThingy)

