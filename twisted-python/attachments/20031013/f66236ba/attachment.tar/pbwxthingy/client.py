from wxPython.wx import *
from twisted.spread import pb, jelly
from twisted.internet import reactor
from twisted.cred import credentials, error
from twisted.python import failure
import sys

from thingies import Thingy, CopyThingy, ReceiverThingy

def getDeferredResult(d, timeout=None):
    """
    Waits for a Deferred to arrive, then returns or throws an
    exception, based on the result.
    """
    from twisted.internet import reactor
    if timeout is not None:
        d.setTimeout(timeout)
    resultSet = []
    d.addCallbacks(resultSet.append, resultSet.append)
    while not resultSet:
        reactor.iterate()
    result = resultSet[0]

    if isinstance(result, failure.Failure):
        print "deferredResult::raise"
        raise result
    else:
        return result


class ServerObjectForUpdates(pb.Referenceable):
    def remote_updateThingy(self, thingy):
        wxGetApp().mainWindow.UpdateForThingyReceived(thingy)


class PBFactory(pb.PBClientFactory):
    def __init__(self):
        pb.PBClientFactory.__init__(self)

    def clientConnectionFailed(self, connector, reason):
        print "clientConnectionFailed", reason
        pb.PBClientFactory.clientConnectionFailed(self,connector, reason)

    def clientConnectionMade(self, broker):
        print "connection made with broker", id(broker), broker
        pb.PBClientFactory.clientConnectionMade(self,broker)
        
    def clientConnectionLost(self, connector, reason):
        print "clientConnectionLost", reason
        pb.PBClientFactory.clientConnectionLost(self,connector, reason)
        wxGetApp().mainWindow.CloseWindow()


class wxMyFrame(wxFrame):
    def __init__(self, parent):
        wxFrame.__init__(self, parent, -1, "MyFrame", size=(650,300),
                             style=wxDEFAULT_FRAME_STYLE | wxNO_FULL_REPAINT_ON_RESIZE)
        self.currentThingy = None
        self.SetupWorkspace()

    def SetupWorkspace(self):
        self.panel = wxPanel(self, -1)

        buttonClose = wxButton(self.panel, 1003, "Close")
        buttonClose.SetPosition(wxPoint(10, 10))

        buttonEcho = wxButton(self.panel, 1004, "GetThingyList")
        buttonEcho.SetPosition(wxPoint(100, 10))

        self.tptextNumber= wxTextCtrl(self.panel, 1005, style=wxTE_READONLY )
        self.tptextNumber.SetPosition(wxPoint(320, 45))
        
        self.tptextWeight= wxTextCtrl(self.panel, 1005)
        self.tptextWeight.SetPosition(wxPoint(320, 75))
        
        self.tptextPlant= wxTextCtrl(self.panel, 1005 )
        self.tptextPlant.SetPosition(wxPoint(320, 105))
        
        buttonSaveChanges = wxButton(self.panel, 1005, "Save Changes")
        buttonSaveChanges.SetPosition(wxPoint(320, 135))
            
        self.tplist = wxListCtrl(self.panel,1006,size=(301,200),style=wxLC_REPORT)
        self.tplist.SetPosition(wxPoint(10, 45))
        self.tplist.InsertColumn(0,"number",wxLIST_FORMAT_LEFT,99)
        self.tplist.InsertColumn(1,"weight",wxLIST_FORMAT_LEFT,99)
        self.tplist.InsertColumn(2,"plant",wxLIST_FORMAT_LEFT,99)
        self.tplist.Refresh()

        EVT_BUTTON(self, 1003, self.OnCloseWindow)
        EVT_BUTTON(self, 1004, self.OnButtonGetThingyList)
        EVT_BUTTON(self, 1005, self.OnButtonSaveChanges)
        EVT_LIST_ITEM_ACTIVATED(self.tplist,1006,self.OnItemActivate)
        EVT_CLOSE(self, self.OnCloseWindow)

    def OnCloseWindow(self, event):
        self.CloseWindow()

    def CloseWindow(self):   
        wxGetApp().factory.disconnect()  
        self.Destroy()

    def OnButtonGetThingyList(self,event):
        self.tplist.DeleteAllItems()
        lst=["number","weight","plant"]
        thingyTuples = wxGetApp().getThingyList(lst)
        
        for thingyFields in thingyTuples:
            self.tplist.InsertStringItem(0,thingyFields[0])
            n = 0
            for field in thingyFields:
                self.tplist.SetStringItem(0,n,field)
                n += 1

    def OnItemActivate(self,event):
        item = self.tplist.GetNextItem(-1,wxLIST_NEXT_ALL,wxLIST_STATE_SELECTED)
        if item != -1 :
            self.currentThingy = wxGetApp().getThingy( self.tplist.GetItemText(item) )
            self.tptextNumber.SetValue( str(self.currentThingy.number))
            self.tptextWeight.SetValue( str(self.currentThingy.weight))
            self.tptextPlant.SetValue( str(self.currentThingy.plant))

    def OnButtonSaveChanges(self,event):
        if self.currentThingy != None:
            if (isinstance(self.currentThingy,Thingy)
                  or isinstance(self.currentThingy,ReceiverThingy)):
                dmy = CopyThingy()
                for k in vars(self.currentThingy):
                    setattr(dmy, k, getattr(self.currentThingy, k))
                self.currentThingy = dmy
            if isinstance(self.currentThingy,CopyThingy):
                #everything ok
                pass

            self.currentThingy.weight = self.tptextWeight.GetValue()
            self.currentThingy.plant = self.tptextPlant.GetValue()
            wxGetApp().UpdateThingy(self.currentThingy)
      
    def UpdateForThingyReceived(self,thingy):
        if isinstance(thingy,Thingy):
            item = self.tplist.FindItem(-1,thingy.number)
            if item != -1: #update thingy
                self.tplist.SetStringItem(item,1,thingy.weight)
                self.tplist.SetStringItem(item,2,thingy.plant)
            
            else: #new thingy, insert
                self.tplist.InsertStringItem(0,thingy.number)
                self.tplist.SetStringItem(0,1,thingy.weight)
                self.tplist.SetStringItem(0,2,thingy.plant)


class wxMyApp(wxApp):
    def __init__(self):
        self.perspective = None
        self.viewpoint = None
        wxApp.__init__(self,0)

    def OnInit(self):
        result = 1
        
        login = "bob"  #"bob" is the default user
        try:
            login = sys.argv[1]
        except:
            pass

        # Start Twisted Code 
        self.factory = PBFactory()
        deferredPerspective = self.factory.login(
                                    credentials.UsernamePassword(
                                        str(login),str(login)), "brains")
        reactor.connectTCP("localhost", 8080, self.factory)
        try:
            self.perspective = getDeferredResult(deferredPerspective)
            self.viewpoint = getDeferredResult(
                                self.perspective.callRemote(
                                        "getViewOnThingies"))
            self.viewpoint.callRemote("subscribe",
                                      ServerObjectForUpdates())
            # the timer replaces reactor.run(), see doc-string in
            # OnTimer(...)
            EVT_TIMER(self,999999,self.OnTimer) 
            self.timer=wxTimer(self,999999)
            self.timer.Start(250,False)
        except:
            # connection not possible or unauthorized, so we don't
            # need the timer and quit
            result = 0

        # End Twisted Code
        
        # Start wxPython Code
        if result == 1:
            self.mainWindow = wxMyFrame(None)
            self.mainWindow.Show(1)
            self.SetTopWindow(self.mainWindow)
        # End wxPython Code
        return result
    
    def getThingyList(self,list=[]):
        return getDeferredResult(
            self.viewpoint.callRemote("getThingyList", list))
          
    def getThingy(self,number):
        return getDeferredResult(
            self.viewpoint.callRemote("getThingy", number))
          
    def UpdateThingy(self, thingy):
        self.viewpoint.callRemote("updateThingy", thingy)
    
    def run(self):
        self.MainLoop()
        
    def OnTimer(self,event):
        """
        http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/181780
        The reactor calls are copied from the select reactors
        mainloop.  Note that the reactor.run() method is never
        called. This neverending loop is emulated by the timer
        events.  Initialize your wxApp as usual by calling
        app.MainLoop() in your main module.  You might have to
        play with the timer value (250 ms above) as well as with
        the timeout value of the doIteration call. If you have
        only a few remote calls you can increase the timer value
        so the OnTimer event will be triggered less often. This
        will increase the responsetime of your application. If
        you do heavy networking via Twisted you might want to
        increase the doIteration timeout (maybe 0.002) and
        probably decrease the timer value to somewhere around
        150ms.  Since the wx mainloop is running normally menus
        and modal dialogs won't block.
        """
        reactor.runUntilCurrent()
        reactor.doIteration(0)
        pass

def main():
    app = wxMyApp()
    app.run()
  
  
if __name__ == '__main__':
	main()
