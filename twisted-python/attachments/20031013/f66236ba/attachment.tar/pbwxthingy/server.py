from twisted.cred.portal import IRealm
from twisted.cred import checkers 
from twisted.cred import portal 
from twisted.internet import reactor
from twisted.spread import pb, jelly

from threading import Timer

import Singleton
from thingies import Thingies, Thingy, CopyThingy, ReceiverThingy


class ClientRealm:
    def __init__(self):
        self.p = ClientPerspective()
    
    def requestAvatar(self, avatarId, mind, interface):
        print "avatarId=",avatarId
        self.p.loggedIn = 1
        self.p.avatarId = avatarId
        return pb.IPerspective, self.p, self.p.logout


class ClientPerspective(pb.Perspective):
    __implements__ = pb.IPerspective,

    def __init__(self):
        pass
    
    def perspective_getViewOnThingies(self):
        return ClientViewOnThingies()

    def logout(self):
        self.loggedOut = 1


class ClientViewOnThingies(pb.Viewable):
    __metaclass__ = Singleton.Singleton

    def __init__(self):
        self.thingies = Thingies()
        self.clients = {}
        
    def view_subscribe(self,perspective,callback):
        print "",perspective.avatarId," subscribed"
        self.clients[perspective.avatarId] = callback

    def view_unsubscribe(self,perspective):
        del self.clients[perspective.avatarId]

    def view_getThingy(self, perspective, number):
        return self.thingies.getThingy(number)

    def view_getThingyList(self, perspective, fields = []):
        return self.thingies.getThingyList(fields)

    def view_updateThingy(self, user, thingy):
        if (isinstance(thingy, Thingy)
        or isinstance(thingy, ReceiverThingy)):
            dmy = CopyThingy()
            for k in vars(thingy):
                setattr(dmy, k, getattr(thingy, k))
            thingy = dmy
        if isinstance(thingy,ReceiverThingy):
            #everything ok
            pass
        if isinstance(thingy,CopyThingy):
            if self.thingies.updateThingy(thingy):
                print len(self.clients.keys())
                for client in self.clients.keys():
                    print client
                    try:
                        print ("calling remote updateThingy()", 
                               client, self.clients[client])
                        self.clients[client].callRemote("updateThingy", thingy)          
                    except:
                        print "Dead Reference", client, self.clients[client]
                        del self.clients[client]          


tps = Thingies()
tps.addThingy( CopyThingy(number="1",weight="12000") )
tps.addThingy( CopyThingy(number="2",weight="22000") )
tps.addThingy( CopyThingy(number="3",weight="12000") )
tps.addThingy( CopyThingy(number="4",weight="13000") )
tps.addThingy( CopyThingy(number="5",weight="14000") )
tps.addThingy( CopyThingy(number="6",weight="17000") )
    

checker = checkers.InMemoryUsernamePasswordDatabaseDontUse()
checker.addUser("bob","bob")
checker.addUser("nici","nici")

realm =  ClientRealm()
portal = portal.Portal(realm)
portal.registerChecker(checker)
server = pb.PBServerFactory(portal)

reactor.listenTCP(8080, server, interface="localhost")
print "running on ", 8080
reactor.run()
print "stopped"


