from twisted.cred import portal, checkers, credentials
from twisted.conch import error, avatar, recvline, interfaces as conchinterfaces
from twisted.conch.telnet import TelnetTransport, TelnetBootstrapProtocol
from twisted.conch.insults import insults
from twisted.application import internet, service
from zope.interface import implements
from twisted.internet import protocol
import os


class TelnetRealm:
	implements(portal.IRealm)
	
	def requestAvatar(self, avatarId, mind, *interfaces):
		if conchinterfaces.IConchUser in interfaces:
			return interfaces[0], TelnetAvatar(avatarId), lambda: None
		else:
			raise Exception, "No supported interfaces found."
			
class TelnetAvatar(avatar.ConchUser):
	implements(conchinterfaces.ISession)
	
	def __init__(self, username):
		avatar.ConchUser.__init__(self)
		self.username = username
		self.channelLookup.update({'session':session.TelnetSession})
		
	def openShell(self, protocol):
		serverProtocol = insults.ServerProtocol(TelnetProtocol, self)
		serverProtocol.makeConnection(protocol)
		protocol.makeConnection(session.wrapProtocol(serverProtocol))
		
	def getPty(self, terminal, windowSize, attrs):
		return None

	def execCommand(self, protocol, cmd):
		raise NotImplementedError
		
	def closed(self):
		pass



class TelnetProtocol(recvline.HistoricRecvLine):
	def __init__(self, user):
		self.user = user
	def connectionMade(self):
		recvline.HistoricRecvLine.connectionMade(self)
		self.terminal.write("welcome\n")
		self.terminal.nextLine( )
		self.showPrompt( )
	def showPrompt(self):
		self.terminal.write("mybox> ")
	def getCommandFunc(self, cmd):
		return getattr(self, 'do_' + cmd, None)
	def lineReceived(self, line):
		line = line.strip( )
		if line:
			cmdAndArgs = line.split( )
			cmd = cmdAndArgs[0]
			args = cmdAndArgs[1:]
			func = self.getCommandFunc(cmd)
			if func:
				try:
					func(*args)
				except Exception, e:
					self.terminal.write("Error: %s" % e)
					self.terminal.nextLine( )
			else:
				self.terminal.write("No such command.")
				self.terminal.nextLine( )
		self.showPrompt( )
		
	def do_quit(self):
		self.terminal.loseConnection( )
	
	def do_show(self, *args):	
		command = "".join(args)
		if command == 'ver' :
			self.terminal.write("show the version\n")
			self.terminal.nextLine( )
		elif command == 'diag' :
			self.terminal.write("diagnostics\n")
			self.terminal.nextLine( )
					
def makeService(args):

    checker = checkers.InMemoryUsernamePasswordDatabaseDontUse(username="password")
    f = protocol.ServerFactory()
    f.protocol = lambda: TelnetTransport(TelnetBootstrapProtocol,
                                         insults.ServerProtocol,
                                         args['protocolFactory'],
                                         *args.get('protocolArgs', ()),
                                         **args.get('protocolKwArgs', {}))
    tsvc = internet.TCPServer(args['telnet'], f)

    m = service.MultiService()
    tsvc.setServiceParent(m)
    return m

application = service.Application("Telnet Server Demo")

makeService({'protocolFactory': TelnetProtocol, 'telnet': 23}).setServiceParent(application)
