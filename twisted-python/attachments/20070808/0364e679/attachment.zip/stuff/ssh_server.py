from twisted.cred import portal, checkers, credentials
from twisted.conch import error, avatar, recvline, interfaces as conchinterfaces
from twisted.conch.ssh import factory, userauth, connection, keys, session, common
from twisted.conch.insults import insults
from twisted.application import service, internet
from zope.interface import implements
import os

class SSHDemoProtocol(recvline.HistoricRecvLine):
	def __init__(self, user):
		self.user = user
	def connectionMade(self):
		recvline.HistoricRecvLine.connectionMade(self)
		self.terminal.write("welcome\n")
		self.terminal.nextLine( )
		#self.do_help( )
		self.showPrompt( )
	def showPrompt(self):
		self.terminal.write("mybox> ")
	def getCommandFunc(self, cmd):
		return getattr(self, 'do_' + cmd, None)
	def lineReceived(self, line):
		line = line.strip( )
		if line:
			cmdAndArgs = line.split( )
			cmd = cmdAndArgs[0]
			args = cmdAndArgs[1:]
			func = self.getCommandFunc(cmd)
			if func:
				try:
					func(*args)
				except Exception, e:
					self.terminal.write("Error: %s" % e)
					self.terminal.nextLine( )
			else:
				self.terminal.write("No such command.")
				self.terminal.nextLine( )
		self.showPrompt( )
		
	def do_quit(self):
		self.terminal.loseConnection( )
	
	def do_show(self, *args):	
		command = "".join(args)
		if command == 'ver' :
			self.terminal.write("show the version\n")
			self.terminal.nextLine( )
		elif command == 'diag' :
			self.terminal.write("diagnostics\n")
			self.terminal.nextLine( )
		
class SSHDemoAvatar(avatar.ConchUser):
	implements(conchinterfaces.ISession)
	
	def __init__(self, username):
		avatar.ConchUser.__init__(self)
		self.username = username
		self.channelLookup.update({'session':session.SSHSession})
		
	def openShell(self, protocol):
		serverProtocol = insults.ServerProtocol(SSHDemoProtocol, self)
		serverProtocol.makeConnection(protocol)
		protocol.makeConnection(session.wrapProtocol(serverProtocol))
		
	def getPty(self, terminal, windowSize, attrs):
		return None

	def execCommand(self, protocol, cmd):
		raise NotImplementedError
		
	def closed(self):
		pass
		
class SSHDemoRealm:
	implements(portal.IRealm)
	
	def requestAvatar(self, avatarId, mind, *interfaces):
		if conchinterfaces.IConchUser in interfaces:
			return interfaces[0], SSHDemoAvatar(avatarId), lambda: None
		else:
			raise Exception, "No supported interfaces found."
			
			
def getRSAKeys( ):
	if not (os.path.exists('public.key') and os.path.exists('private.key')):
		# generate a RSA keypair
		print "Generating RSA keypair..."
		from Crypto.PublicKey import RSA
		KEY_LENGTH = 1024
		rsaKey = RSA.generate(KEY_LENGTH, common.entropy.get_bytes)
		publicKeyString = keys.makePublicKeyString(rsaKey)
		privateKeyString = keys.makePrivateKeyString(rsaKey)
		# save keys for next time
		file('public.key', 'w+b').write(publicKeyString)
		file('private.key', 'w+b').write(privateKeyString)
		print "done."
	else:
		publicKeyString = file('public.key').read( )
		privateKeyString = file('private.key').read( )
	return publicKeyString, privateKeyString
	
if __name__ == "__main__":
	sshFactory = factory.SSHFactory( )
	sshFactory.portal = portal.Portal(SSHDemoRealm( ))
	users = {'testlab': 'testlab', 'guest': 'bbb'}
	sshFactory.portal.registerChecker(
		checkers.InMemoryUsernamePasswordDatabaseDontUse(**users))
		
	pubKeyString, privKeyString = getRSAKeys( )
	sshFactory.publicKeys = {
		'ssh-rsa': keys.getPublicKeyString(data=pubKeyString)}
	sshFactory.privateKeys = {
		'ssh-rsa': keys.getPrivateKeyObject(data=privKeyString)}
		
from twisted.internet import reactor
reactor.listenTCP(22, sshFactory)
reactor.run( )