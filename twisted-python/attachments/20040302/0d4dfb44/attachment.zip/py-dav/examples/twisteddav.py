from twisted.web import server
from twisted.internet import reactor

from pydav.twisted_dav import TwistedDAVRequestHandler, WebDAV

from data import dataclass


class mydavHandler(TwistedDAVRequestHandler):
    IFACE_CLASS=dataclass()

    #sample of how to use authorization.
    def get_userinfo(self, user, password):
        return True
        if user == "test" and password == "test":
            return True
        return False
        
if __name__=="__main__":
    handler = mydavHandler()
    wdav = WebDAV(handler)
    reactor.listenTCP(7080, server.Site(wdav))
    reactor.run()
    
    
    
    
    
