"""
$Id: twisted_dav.py,v 1.6 2004/01/15 17:22:34 henni Exp $

WebDAV for twisted

The TwistedDAVRequestHandler handles a HTTP Request and maps all WevDAV specific methods to
a class-interface (IFACE_CLASS), which must implement all methods in iface.dav_interface
see the examples for more details.

All responses will be converted to WebDAV-XML by the TwistedDAVRequestHandler.

Furthermore WebDAV implements a twisted.web.resource.Resource, such that all HTTP-Reuqests will be
passed to the TwistedDAVRequestHandler.
The 'render' method will be called, when a request is finished.

Be careful:
TwistedDAVRequestHandler uses deferreds, since some request may take a while.
However, those deferreds will be stored into a DeferredLists as 'tasks'.
After all tasks are processed, the render method of the resource is called.

Properties of objects (PROPFIND) may never ever return a deferred, they MUST return a value.
"""
from __future__ import nested_scopes

# System Imports
import urlparse
import os
import sys
import time
import socket
import string
import posixpath
import SocketServer
import BaseHTTPServer
import base64
import AuthServer
import urlparse
import urllib

# Sibling Imports
from twisted.web import resource, server
from twisted.internet import defer, protocol, reactor
from twisted.python import log, reflect
from twisted.protocols import http

#WebDAV imports
from propfind import PROPFIND
from delete import DELETE
from davcopy import COPY
from davmove import MOVE

from string import atoi,split
from status import STATUS_CODES
from errors import *

# Default error message
DEFAULT_ERROR_MESSAGE = """\
<head>
<title>Error response</title>
</head>
<body>
<h1>Error response</h1>
<p>Error code %(code)d.
<p>Message: %(message)s.
<p>Error code explanation: %(code)s = %(explain)s.
</body>
"""

AUTH_ERROR_MSG="""<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML><HEAD>
<TITLE>401 Authorization Required</TITLE>
</HEAD><BODY>
<H1>Authorization Required</H1>
This server could not verify that you
are authorized to access the document
requested.  Either you supplied the wrong
credentials (e.g., bad password), or your
browser doesn't understand how to supply
the credentials required.<P>
</BODY></HTML>"""

class TwistedDAVRequestHandler:

    # set this to false, if you do not need any authorization.
    DO_AUTH = True
    
    __version__ = "0.5"

    # The Python system version, truncated to its first component.
    sys_version = "Python/" + sys.version.split()[0]

    server_version = "DAV/" + __version__
    protocol_version="HTTP/1.0"
    error_message_format = DEFAULT_ERROR_MESSAGE
    auth_error_msg = AUTH_ERROR_MSG
    
    weekdayname = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

    monthname = [None,
                 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    ### utility functions

    def __init__(self):
        self.responses = {}
        self.newheaders = []
        self._init_buffer()

    def version_string(self):
        """Return the server software version string."""
        return self.server_version + ' ' + self.sys_version
    
    def date_time_string(self):
        """Return the current date and time formatted for a message header."""
        now = time.time()
        year, month, day, hh, mm, ss, wd, y, z = time.gmtime(now)
        s = "%s, %02d %3s %4d %02d:%02d:%02d GMT" % (
                self.weekdayname[wd],
                day, self.monthname[month], year,
                hh, mm, ss)
        return s

    def log_date_time_string(self):
        """Return the current time formatted for logging."""
        now = time.time()
        year, month, day, hh, mm, ss, x, y, z = time.localtime(now)
        s = "%02d/%3s/%04d %02d:%02d:%02d" % (
                day, self.monthname[month], year, hh, mm, ss)
        return s


    def address_string(self):
        """Return the client address formatted for logging.

        This version looks up the full hostname using gethostbyaddr(),
        and tries to find a name that contains at least one dot.

        """
        host, port = self.client_address[:2]
        return socket.getfqdn(host)

    def getBuffer(self):
        return self.__buffer
    
    def _init_buffer(self):
        """initialize the buffer. 
        """
        self.newheaders = []
        self.__buffer=""

    def handle(self, request):
        """Handle a single HTTP request.

        You normally don't need to override this method; see the class
        __doc__ string for information on how to handle specific HTTP
        commands such as GET and POST.
        """
        self._init_buffer()

        dc=self.IFACE_CLASS
        dc.tasks=[]

        self.request = request
        self.headers = request.getAllHeaders()
        self.rfile = request.content
        
        self.command = None
        
        self.command, self.path, self.request_version = request.method, request.uri, request.clientproto 

	# test authentification
	if self.DO_AUTH:
	    try:
                a=self.headers["authorization"]
                m,up=string.split(a)
                up2=base64.decodestring(up)
                user,pw=string.split(up2,":")
                if not self.get_userinfo(user,pw):
                    self.send_autherror(401,"Authorization Required")
                    return []
            except:
                self.send_autherror(401,"Authorization Required")
                return []


        mname = 'do_' + self.command
        if not hasattr(self, mname):
            log.msg("UNSUPPORTED -> " + mname)
            self.send_error(501, "Unsupported method (%s)" % self.command)
            return []
        
        method = getattr(self, mname)

        log.msg("EXCECUTING -> "+ mname)
        
        # ... this returns, when done ...
        method()

        dc=self.IFACE_CLASS
        #returns all tasks for this request (maybe some deferreds maybe not)!
        # the IFACE CLASS can decide this!
        return dc.tasks
        
    def get_userinfo(self,user,pw):
    	""" Dummy method which lets all users in, overwrite this, if you need authorization"""
	return 1
	
    def _append(self,s):
        """ append a string to the buffer """
        self.__buffer=self.__buffer+s

    def send_autherror(self,code,message=None):
        try:
            short, long = self.responses[code]
        except KeyError:
            short, long = '???', '???'
        if not message:
            message = short
        explain = long

	emsg=self.auth_error_msg
        self.send_response(code, message)
	self.send_header("WWW-Authenticate","Basic realm=\"bbot\"")
        self.send_header("Content-Type", 'text/html')
        self.send_header("MS-Author-via", "DAV")

	lines=split(emsg,"\n")
	for l in lines:
            self._append("%s\r\n" %l)


    def send_error(self, code, message=None):
        """Send and log an error reply.

        Arguments are the error code, and a detailed message.
        The detailed message defaults to the short entry matching the
        response code.

        This sends an error response (so it must be called before any
        output has been generated), logs the error, and finally sends
        a piece of HTML explaining the error to the user.

        """
        try:
            short, long = self.responses[code]
        except KeyError:
            short, long = '???', '???'
            
        if message is None:
            message = short
            
        explain = long
        content = (self.error_message_format %
                   {'code': code, 'message': message, 'explain': explain})
        self.send_response(code, message)
        self.send_header("Content-Type", "text/html")
        self.send_header('Connection', 'close')
        self.send_header("MS-Author-via", "DAV")
        
        if self.command != 'HEAD' and code >= 200 and code not in (204, 304):
            self._append(content)

    def send_header(self, keyword, value):
        """Send a MIME header."""
        self.request.setHeader(keyword, value)

        
    def send_response(self, code, message=None):
        if message is None:
            if self.responses.has_key(code):
                message = self.responses[code][0]
            else:
                message = ''
                
        self.request.version = self.protocol_version
        self.request.code    = int(code)
        self.request.code_message = message

        self.send_header('Server', self.version_string())
        self.send_header('Connection', 'close')
        self.send_header('Date', self.date_time_string())
        self.send_header("MS-Author-via", "DAV")

    
    def send_body(self,DATA,code,msg,desc,ctype='application/octet-stream',headers={}):
	""" send a body in one part """

        print "SEND BODY -> ", headers

	self.send_response(code,message=msg)
        self.send_header("Connection", "close")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("MS-Author-via", "DAV")
                
	for a,v in headers.items():
	    self.send_header(a,v)
	if DATA:
            
	    self.send_header("Content-Length", str(len(DATA)))
	    self.send_header("Content-Type", ctype)
            self._append(DATA)
            
	else:
	    self.send_header("Content-Length", "0")
            

    def send_body_chunks(self,DATA,code,msg,desc,ctype='text/xml; encoding="utf-8"', headers=None):
	""" send a body in chunks """

        
        self.responses[207]=(msg,desc)
            
	self.send_response(code,message=msg)

        if headers:
            for a,v in headers.items():
                self.send_header(a,v)
            

        self.send_header("Content-type", ctype)
        self.send_header("Connection", "close")
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("MS-Author-via", "DAV")

	self._append(DATA)


    ### HTTP METHODS

    def do_OPTIONS(self):
    	"""return the list of capabilities """
        self.send_response(200)
        self.send_header("Allow", "GET, HEAD, COPY, MOVE, POST, PUT, PROPFIND, PROPPATCH, OPTIONS, MKCOL, DELETE, TRACE")
        self.send_header("Content-Type", "text/plain")
        self.send_header("DAV", "1")
        self.send_header("MS-Author-via", "DAV")


    def do_PROPFIND(self):

    	dc=self.IFACE_CLASS
	# read the body
	body=self.rfile.read()

	# which Depth?
	if self.headers.has_key('depth'):
            d=self.headers['depth']
	else:
            d="infinity"

	uri=urlparse.urljoin(dc.BASEURI,self.path)
	uri=urllib.unquote(uri)
        print "URI=", uri
        
    	pf=PROPFIND(uri,dc,d)

	if body:	
	    pf.read_propfind(body)
        try:
	    DATA=pf.createResponse()
	    DATA=DATA+"\n"
	except DAV_Error, (ec,dd):
	    return self.send_status(ec)

	self.send_body_chunks(DATA,"207","Multi-Status","Multiple responses")


    def do_GET(self):
        """Serve a GET request."""
    	dc=self.IFACE_CLASS
	uri=urlparse.urljoin(dc.BASEURI,self.path)
	uri=urllib.unquote(uri)

	# get the last modified date
	try:
	    lm=dc.get_prop(uri,"DAV:","getlastmodified")
	except:
	    lm="Sun, 01 Dec 2014 00:00:00 GMT"	# dummy!
	headers={"Last-Modified":lm}

	# get the content type
	try:
	    ct=dc.get_prop(uri,"DAV:","getcontenttype")
	except:
	    ct="application/octet-stream"

        data=""

        d = dc.get_data(uri)
        if d is None:
            self.send_status(204)
            return

        #at the moment, we do not need a deferred.
        #cbStoreData(d)
        #self.send_body(d,"200","OK","OK",ct,headers)

        #send chunked?
        self.send_body_chunks(d,"200","OK","OK",ct,headers)
        
#
        
        
#        d.addCallback( cbStoreData )
#        d.addErrback( cbError )
#        dc.tasks.append(d)


    def do_HEAD(self):
	""" Send a HEAD response """
    	dc=self.IFACE_CLASS
        
	uri=urlparse.urljoin(dc.BASEURI,self.path)
	uri=urllib.unquote(uri)

        print "HEAD CALL -> " + uri
        if not dc.exists(uri):
            self.send_error(404,"File not found")
            return

        headers={}
        
	# get the last modified date
	try:
	    lm=dc.get_prop(uri,"DAV:","getlastmodified")
	except:
	    lm="Sun, 01 Dec 2014 00:00:00 GMT"	# dummy!
	headers={"Last-Modified":lm}


	# get the content type
	try:
	    ct=dc.get_prop(uri,"DAV:","getcontenttype")
	except:
	    ct="application/octet-stream"

        size = dc._get_dav_getcontentlength(uri)
        
        headers["Content-Length"]=size
        self.send_body(None,"200","OK","OK",ct,headers)
        

    def do_POST(self):
    	self.send_error(404,"File not found")

    def do_MKCOL(self):
    	""" create a new collection """
    	dc=self.IFACE_CLASS
	uri=urlparse.urljoin(dc.BASEURI,self.path)
	uri=urllib.unquote(uri)
	try:
	    dc.mkcol(uri)
	    self.send_status(200)
	except DAV_Error, (ec,dd):
	    self.send_status(ec)

    def do_DELETE(self):
    	""" delete an resource """
    	dc=self.IFACE_CLASS
	uri=urlparse.urljoin(dc.BASEURI,self.path)
	uri=urllib.unquote(uri)
    	dl=DELETE(uri,dc)
	if dc.is_collection(uri):
	    res=dl.delcol()
	else:
	    res=dl.delone()
	if res:
	    self.send_status(207,body=res)
	else:
	    self.send_status(204)

    def do_PUT(self):
    	dc=self.IFACE_CLASS
	# read the body
	body=None
	if self.headers.has_key("content-length"):
		l=self.headers['content-length']
		body=self.rfile.read(atoi(l))
	uri=urlparse.urljoin(dc.BASEURI,self.path)
	uri=urllib.unquote(uri)

	ct=None
	if self.headers.has_key("content-type"):
	    ct=self.headers['content-type']
	try: 
	    dc.put(uri,body,ct)
	except DAV_Error, (ec,dd):
	    self.send_status(ec)
	    return
	self.send_status(201)

    def do_COPY(self):
	""" copy one resource to another """
        
	try:
	    self.copymove(COPY)
	except DAV_Error, (ec,dd):
	    self.send_status(ec)

    def do_MOVE(self):
	""" move one resource to another """
	try:
	    self.copymove(MOVE)
	except DAV_Error, (ec,dd):
	    self.send_status(ec)


    def copymove(self,CLASS):
	""" common method for copying or moving objects """
	dc=self.IFACE_CLASS

	# get the source URI
	source_uri=urlparse.urljoin(dc.BASEURI,self.path)
	source_uri=urllib.unquote(source_uri)

	# get the destination URI
	dest_uri=self.headers['destination']
	dest_uri=urllib.unquote(dest_uri)

	# Overwrite?
	overwrite=1
	result_code=204
	if self.headers.has_key("overwrite"):
	    if self.headers['overwrite']=="F":
		overwrite=None
		result_code=201

	# instanciate ACTION class
    	cp=CLASS(dc,source_uri,dest_uri,overwrite)

	# Depth?
	d="infinity"
	if self.headers.has_key("Depth"):
	    d=self.headers['Depth']
	    if d!="0" and d!="infinity": 
    		self.send_status(400)
		return
	    if d=="0":	
		result_code=cp.single_action()
    		self.send_status(result_code)
		return

	# now it only can be "infinity" but we nevertheless check for a collection
	if dc.is_collection(source_uri):
	    try:
		res=cp.tree_action()
	    except DAV_Error, (ec,dd):
		self.send_status(ec)
		return
	else:
	    try:
		result_code=cp.single_action()
                res = None
	    except DAV_Error, (ec,dd):
		self.send_status(ec)
		return

	if res:
            self.send_body_chunks(res,207,STATUS_CODES[207],STATUS_CODES[207],
					    ctype='text/xml; charset="utf-8"')
	else:
            self.send_status(result_code)


    def send_status(self,code=200,mediatype='text/xml;  charset="utf-8"', msg=None,body=None):
    	if not msg:
            msg="OK"

        if code not in STATUS_CODES:
            log.msg("WRONG STATUS_CODE -> "+ str(code))
            self.send_body(body,200,"OK", "OK",mediatype)
        else:
            sendstatus = STATUS_CODES[code]
            self.send_body(body,code,sendstatus,msg,mediatype)




class WebDAV(resource.Resource):
    """
    A resource that implements WebDAV.
    """

    # Error codes for Twisted, if they conflict with yours then
    # modify them at runtime.
    NOT_FOUND = 8001
    FAILURE = 8002

    isLeaf = 1
    
    def __init__(self, davRequestHandler):
        """
        Init a WebDAV Resource.

        @param davRequestHandler: Implementation of the pydav.davserver for twisted.
        @type TwistedDAVRequestHandler.
        """
        resource.Resource.__init__(self)
        self.davRequestHandler = davRequestHandler
    
    def render(self, request):
        """
        Render will be called for any incoming request.
        """
        self.request = request
        request.content.seek(0, 0)

        #ok maybe "handle" returns a DeferredList with all upcoming tasks for this request.
        # after all deferreds done -> _cdRenber will be called and the data sent to the client.
        def handleTasks( tasks ):
            if tasks:
                print "HANDLE TASKS = ", tasks
                dList = defer.DeferredList(tasks)
                dList.addCallback(self._cbRender).addErrback(self._ebRender)
            else:
                print "JUST SEND = ", tasks
                self._cbRender(None)
                
        defer.maybeDeferred(self.davRequestHandler.handle, self.request).addErrback(
            self._ebRender
            ).addCallback(
            handleTasks
            )

        #Indicates, that response will be sent later to the client
        return server.NOT_DONE_YET

    def _cbRender(self, result):
        """
        Callback for sending data over the wire.
        
        @param result: the result of the last task in the DeferredList or None.
        """
        response = self.davRequestHandler.getBuffer()
        self.request.write(response)
        self.request.finish()
        
    def _ebRender(self, failure):
        """
        Error occured will procesiing all tasks.
        """
        return failure
