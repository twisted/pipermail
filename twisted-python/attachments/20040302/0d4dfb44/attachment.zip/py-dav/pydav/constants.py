"""

constants definition


"""

# definition for resourcetype
COLLECTION=1
OBJECT=None
DAV_PROPS=['creationdate', 'displayname', 'getcontentlanguage', 'getcontentlength', 'getcontenttype', 'getetag', 'getlastmodified', 'lockdiscovery', 'resourcetype', 'source', 'supportedlock']


# Request classes in propfind

RT_ALLPROP=1
RT_PROPNAME=2
RT_PROP=3
