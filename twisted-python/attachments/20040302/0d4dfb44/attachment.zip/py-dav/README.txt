pydav: a Python WebDAV server 

This package is taken from:
http://comlounge.net/webdav/

checkout the examples in the examples directory to see how it works.

to run the examples, just run "davtest.py". this will setup a WebDAV server of /tmp.
to connect to this server, use a command line WebDAV client, such as "cadaver".

TODO:
+ Http-Port is not configarable yet (default 8000)

TWISTED WEBDAV
==============

checkout the twistedav.py in examples, this works together with a twisted reactor.
this one uses "twisted_dav.py" in "pydav", which emulates a synchronous http-server.

This example emulates a file system.

This Server should work together e.g. with the windows explorer.
Start the server and then try "add network resource", type in a appropiate url.

Checkout pydav to find out, how to write other interfaces ...


have fun!















