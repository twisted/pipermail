#!/usr/bin/env python

import sys

from bbutils.version import version
from distutils.core import setup

packages = ["pydav"]

setup(name = "pydav",
      description="Python WebDAV server",
      version = "0.5",
      packages = packages,
      maintainer="Christian Scholz",maintainer_email="mrtop@webdav.de",
      url="http://comlounge.net/webdav/")
