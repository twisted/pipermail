# Copyright (C) 2005 Darrell Karbott (djk2005 at users dot sf dot net)
# This code is free software; you can redistribute it and/or modify
# it under the terms of the GNU Public Licence (GPL) version 2 See
# http://www.gnu.org/ for further details of the GPL.

from OpenSSL import SSL, crypto
from twisted.internet import ssl
from infocallback import ssl_info_callback

class VerifyingBase:
    def __init__(self, ownCertFile, ownKeyFile):
        self.allowedCertificates = []
        bytes = file(ownCertFile).read()
        self.ownCert = crypto.load_certificate(crypto.FILETYPE_PEM, bytes)
        bytes = file(ownKeyFile).read()
        self.ownKey = crypto.load_privatekey(crypto.FILETYPE_PEM, bytes)
        #self.ownCertFile = ownCertFile
        #self.ownKeyFile  = ownKeyFile
        
    # NOTE: Doesn't add the certificate to existing contexts.
    def loadAllowedCertificate(self, fileName):
        bytes = file(fileName).read()
        self.allowedCertificates.append(crypto.load_certificate(crypto.FILETYPE_PEM, bytes))

    def addAllowedCertificatesToContext(self, ctx):
        store = ctx.get_cert_store()
        for cert in self.allowedCertificates:
            store.add_cert(cert)

    # initialization which is the same for both client and server.
    def initContext(self, ctx):
        # REDFLAG: Also fails
        #ctx.use_certificate_file(self.ownCertFile)
        #ctx.use_privatekey_file(self.ownKeyFile)
        #if not ctx.check_privatekey():
        #    raise "The private key doesn't match the cert. 0"
        
        ctx.use_certificate(self.ownCert)
        ctx.use_privatekey(self.ownKey)
        # REDFLAG: why does this trip!
        # if not ctx.check_privatekey():
        #    raise "The private key doesn't match the cert."
        
        self.addAllowedCertificatesToContext(ctx)
        ctx.set_verify(SSL.VERIFY_PEER | SSL.VERIFY_FAIL_IF_NO_PEER_CERT, self.verify_certificate)
        ctx.set_info_callback(ssl_info_callback)
        return ctx
        
    def verify_certificate(self, conn, cert, errno, depth, retcode):
        print "verify_certificate: ", cert, errno, depth, retcode
        # UNDOCUMENTED:
        # retcode is non-zero if the built in verification code would
        # succeed, false otherwise.
        # UNDOCUMENTED:
        # See http://divmod.org/websvn/wsvn/Quotient/trunk/mantissa/sslverify.py?op=file&rev=0&sc=0
        # _errorcodes for errno descriptions. 
        if not retcode:
            print "VERIFICATION FAILED: ", errno

        return retcode

class VerifyingClientContextFactory(ssl.ClientContextFactory, VerifyingBase):
    def getContext(self):
        return self.initContext(SSL.Context(self.method))

class VerifyingServerContextFactory(VerifyingBase):
    def getContext(self):
        return self.initContext(SSL.Context(SSL.SSLv23_METHOD))

    
