#!/usr/bin/env python
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.

# Modified to support client authentication by
# djk2005 at users dot sf dot net

from verifiedssl import VerifyingServerContextFactory

############################################################
# NOTE: You can generate the cert / key pairs with
#       make_demo_keys.sh
CLIENT_CERT_FILE = "ss_cert_b.pem"

# Use this instead to test that verification fails.
#CLIENT_CERT_FILE = "ss_cert_d.pem"

SERVER_CERT_FILE = "ss_cert_a.pem"
SERVER_KEY_FILE  = "ss_key_a.pem"
############################################################

if __name__ == '__main__':
    import echoserv, sys
    from twisted.internet.protocol import Factory
    from twisted.internet import ssl, reactor
    from twisted.python import log
    log.startLogging(sys.stdout)

    factory = Factory()
    factory.protocol = echoserv.Echo

    ctxFactory = VerifyingServerContextFactory(SERVER_CERT_FILE, SERVER_KEY_FILE)
    # Only clients presenting this certificate are allowed
    # to connect to the server.
    ctxFactory.loadAllowedCertificate(CLIENT_CERT_FILE)

    reactor.listenSSL(8000, factory, ctxFactory)
    reactor.run()
