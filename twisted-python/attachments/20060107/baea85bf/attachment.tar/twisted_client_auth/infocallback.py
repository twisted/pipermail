# Cribbed from M2Crypto cb.py which,
# Cribbed from OpenSSL's apps/s_cb.c.

from OpenSSL import SSL

# REDFLAG: Had to use print. writing to sys.stderr didn't work!

# from ssl.h
SSL_ST_CONNECT = 0x1000
SSL_ST_ACCEPT  = 0x2000
SSL_ST_MASK    = 0x0FFF

SSL_CB_LOOP    = 0x01
SSL_CB_EXIT    = 0x02
SSL_CB_READ    = 0x04
SSL_CB_WRITE   = 0x08
SL_CB_ALERT    = 0x4000 

def ssl_info_callback(connection, where, ret):
    #ssl_conn = Connection.map()[ssl_ptr]
    #sys.stdout.write(ssl_ptr + ':' + str(sys.getrefcount(ssl_conn)) + '\n')
    #sys.stdout.flush()

    w = where & ~SSL_ST_MASK
    if (w & SSL_ST_CONNECT):
        state = "SSL connect"
    elif (w & SSL_ST_ACCEPT):
        state = "SSL accept"
    else:
        state = "SSL state unknown"

    if (where & SSL_CB_LOOP):
        #sys.stderr.write("LOOP: %s: %s\n" % (state, m2.ssl_get_state_v(ssl_ptr)))
        print "LOOP: %s: %s\n" % (state, connection.state_string())
        return

    if (where & SSL_CB_EXIT):
        if not ret:
            print "FAILED: %s: %s\n" % (state, connection.state_string())
        else:
            print "INFO: %s: %s\n" % (state, connection.state_string())
        return

    # I don't think this code would ever execute under pyOpenSSL because
    # it handles alerts with exception, but I'm not sure.
    if (where & SSL_CB_ALERT):
        if (where & SSL_CB_READ):
            w = 'read'
        else:
            w = 'write'
        #sys.stderr.write("ALERT: %s: %s: %s\n" % \
        #    (w, m2.ssl_get_alert_type_v(ret), m2.ssl_get_alert_desc_v(ret)))
        print "ALERT: %s: DUNNO HOW TO GET ALERT INFO!\n" % \
            (w)
        return


