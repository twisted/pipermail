#!/usr/bin/env sh

# ATTRIBUTION:
# See http://www.madboa.com/geek/openssl/#cert-self

# This script generates the self-signed cert / key pairs
# referenced in echoserv_ssl.py and echoclient_ssl.py

openssl req \
  -x509 -nodes -days 365 \
  -subj '/C=US/ST=Oregon/L=Portland/CN=devnull.org' \
  -newkey rsa:1024 -keyout ss_key_a.pem -out ss_cert_a.pem

openssl req \
  -x509 -nodes -days 365 \
  -subj '/C=US/ST=Oregon/L=Portland/CN=devnull.org' \
  -newkey rsa:1024 -keyout ss_key_b.pem -out ss_cert_b.pem

openssl req \
  -x509 -nodes -days 365 \
  -subj '/C=US/ST=Oregon/L=Portland/CN=devnull.org' \
  -newkey rsa:1024 -keyout ss_key_c.pem -out ss_cert_c.pem

openssl req \
  -x509 -nodes -days 365 \
  -subj '/C=US/ST=Oregon/L=Portland/CN=devnull.org' \
  -newkey rsa:1024 -keyout ss_key_d.pem -out ss_cert_d.pem
