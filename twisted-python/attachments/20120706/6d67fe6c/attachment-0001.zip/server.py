import sys

from twisted.internet import reactor
from twisted.python import log
from twisted.web import resource, server


class Resource(resource.Resource):
    isLeaf = True

    def render_GET(self, request):
        return """
        <html>
        <body>
          <form enctype="multipart/form-data" action="/" method="post">
            <input name="a" value="1">
            <input name="b" value="2">
            <input type="file" name="image">
            <input type="submit">
          </form>
        </body>
        </html>
        """

    def render_POST(self, request):
        keys = request.args.keys()
        log.msg("Got POST request, arg keys: {}".format(keys))
        if not keys:
            log.msg("Dropping into debugger...")
            import pdb; pdb.set_trace()
        return ""


log.startLogging(sys.stdout, 0)
reactor.listenTCP(8080, server.Site(Resource()))
reactor.run()
