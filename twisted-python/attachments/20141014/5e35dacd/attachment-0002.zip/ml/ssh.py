#!/usr/bin/env python

# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

from twisted.conch.client.connect import connect
from twisted.conch.client.default import SSHUserAuthClient, verifyHostKey
from twisted.conch.ssh import transport, connection, common, keys, channel
from twisted.conch.scripts.cftp import ClientOptions
from twisted.internet import reactor, defer, protocol
from twisted.python import log
import struct, sys, getpass, os
from time import sleep


def executeRemoteCommands(host, tasks):
    TaskContainer.tasks = tasks
    TaskContainer.host = host
    protocol.ClientCreator(reactor, SimpleTransport).connectTCP(host, 22)


class TaskContainer:
    tasks = []
    host = ''

class SimpleTransport(transport.SSHClientTransport):
    def verifyHostKey(self, hostKey, fingerprint):
        print 'host key fingerprint: %s' % fingerprint
        return defer.succeed(1) 

    def connectionSecure(self):
        conn = SimpleConnection()
        options = ClientOptions()
        options['host'] = TaskContainer.host
        vhk = verifyHostKey
        uao = SSHUserAuthClient(getpass.getuser(), options, conn)
        connect(TaskContainer.host, 22, options, vhk, uao).addErrback(_ebExit)
        self.requestService(uao)

def _ebExit(f):
    if hasattr(f.value, 'value'):
        s = f.value.value
    else:
        s = str(f)
    if s != 'no more authentication methods available':
        print s

class SimpleConnection(connection.SSHConnection):
    def serviceStarted(self):
        tindex = 0
        self.finished_count = 0
        for task in TaskContainer.tasks:
            ##print 'starting %s' % task
            self.openChannel(TaskChannel(tindex, 2**16, 2**15, conn=self))
            tindex+=1
    
    def taskFinished(self):
        self.finished_count += 1
        if self.finished_count >= TaskContainer.tasks.len():
            self.loseConnection()

class TaskChannel(channel.SSHChannel):
    name = 'session' # needed for commands
    
    def __init__(self, tindex, *args, **kwargs):
        channel.SSHChannel.__init__(self, *args, **kwargs)
        self.tindex = tindex
    
    def openFailed(self, reason):
        print '?Execution of remote command failed', reason
    
    def channelOpen(self, ignoredData):
        ##print 'channelOpen: %s; connection:%s' % (self.tindex, repr(self.conn))
        self.data = ''
        self.conn.sendRequest(self, 'exec', 
            common.NS(TaskContainer.tasks[self.tindex]), wantReply = 1)
    
    def request_exit_status(self, data):
        status = struct.unpack('>L', data)[0]
        if status != 0:
            print '?%s failed with status %d' % (TaskContainer.tasks[self.tindex], status)
    
    def dataReceived(self, data):
        self.data += data
    
    def extReceived(self, dataType, data):
        print '?%s failed, because %s' % (TaskContainer.tasks[self.tindex], repr(data))
    
    def closed(self):
        print '%s: %s' % (TaskContainer.tasks[self.tindex], str(self.data))
        self.loseConnection()

