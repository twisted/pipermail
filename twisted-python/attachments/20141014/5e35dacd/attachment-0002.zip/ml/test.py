from sftp import distributeFiles
from ssh import executeRemoteCommands
from twisted.internet import reactor
import os, sys

# To run this code:
somehost =          # TBD; needs public key auth. 
# touch /tmp/file1 ;  /tmp/file2

localdir = '/tmp'
    
def dc():
    
    # this should work alone:
    distributeFiles('somehost', [ 'cd /tmp',
                            'put file1 /tmp/file1',
                            'put file2 /tmp/file2',
                            'chmod 400 /tmp/file1',
                            'chown 26 /tmp/file1',
                            'ls -la ',
                            'rm /tmp/file1',
                            'rm /tmp/file2',
                            'ls -la '])
    
    # this should work alone, but does not exit:
    executeRemoteCommands('somehost', ['hostname','date', 'uname -a'])


if __name__ == '__main__':

    if not reactor.running:
        os.chdir(localdir)
        reactor.callLater(0.001, dc)
        reactor.run()
    else:
        dc()
