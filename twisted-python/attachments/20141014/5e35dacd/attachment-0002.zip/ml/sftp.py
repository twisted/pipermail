 # -*- coding: utf-8 -*


"""
Certificate distribution module.
"""


import getpass, sys
from twisted.conch.client.connect import connect
from twisted.conch.client.default import SSHUserAuthClient, verifyHostKey
from twisted.conch.ssh import connection, common
from twisted.conch.ssh import channel, filetransfer
from twisted.conch.scripts import cftp
from twisted.internet import reactor, defer, stdio
from twisted.python import log #, usage, failure


certdir = '/Administration/CA/CA_py/productive_CA/work'

def distributeFiles(host, tasks):
    if len(tasks) == 0:
        raise IndexError, 'Internal error: Empty task queue in distributeCert' 
    options = cftp.ClientOptions()
    options['host'] = host
    options['port'] = 22
    options['user'] = getpass.getuser()
    options['subsystem'] = 'sftp'
    options['exit_d'] = defer.Deferred()
    args = sys.argv[1:]
    if '-v' in args:
        options['verbose'] = True
    if '-l' in args:
        options['log'] = True
    if options['log']:
        realout = sys.stdout
        log.startLogging(sys.stderr)
        sys.stdout = realout
    else:
        log.discardLogs()
    doConnect(reactor, options, tasks)

# some function and subclasses from cftp 

def doConnect(reactor, options, tasks):

    host = options['host']
    port = options['port']
    conn = SSHConn()
    conn.options = options
    conn.tasks = tasks
    vhk = verifyHostKey
    uao = SSHUserAuthClient(options['user'], options, conn)
    connect(host, port, options, vhk, uao).addErrback(_ebExit)

def _ebExit(f):
    if hasattr(f.value, 'value'):
        s = f.value.value
    else:
        s = str(f)
    print s


class SSHConn(connection.SSHConnection):
    def serviceStarted(self):
        self.openChannel(SSHSession())
    
    def channelClosed(self, channel):
        ##pdb.set_trace()
        connection.SSHConnection.channelClosed(self,channel)
        if len(self.channels) == 0:
            print '[Last channel closed.]'
    

class SSHSession(cftp.SSHSession):
    def _cbSubsystem(self, result):
        self.client = filetransfer.FileTransferClient()
        self.client.makeConnection(self)
        self.dataReceived = self.client.dataReceived
        f = None
        self.stdio = stdio.StandardIO(certSftpClient(self.client, f))
    
    def eofReceived(self):
        log.msg('got eof -- none expected')
        self.stdio.closeStdin()



class certSftpClient(cftp.StdioClient):
    def __init__(self, client, f = None, ):
        self.client = client
        self.currentDirectory = ''
        self.file = f
        self.useProgressBar = False
        self.tasks = []
        self.tindex = 0
    
    def _newLine(self):
        if self.client.transport.localClosed:
            return
        if len(self.tasks) == 0:
            self.tasks = self.client.transport.conn.tasks
        self.ignoreErrors = 0
        if self.tindex >= len(self.tasks):
            self.lineReceived('exit')
            return
        t = self.tasks[self.tindex].strip()
        if not (t.startswith('get') or t.startswith('put')):
            print '[%s]' % t
        self.tindex += 1
        self.lineReceived(t)

    def closed(self):
        pass
