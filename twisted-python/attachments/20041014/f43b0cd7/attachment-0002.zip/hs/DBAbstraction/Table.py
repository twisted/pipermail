import types
import string
import new

from Common import *
from Column import *
from Connection import SQLiteConnection, MySQLConnection

#
# From ASPN, submitted by Scott David Daniels, http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/52549
#
class curry:
    def __init__(self, fun, *args, **kwargs):
        self.fun = fun
        self.pending = args[:]
        self.kwargs = kwargs.copy()

    def __call__(self, *args, **kwargs):
        if kwargs and self.kwargs:
            kw = self.kwargs.copy()
            kw.update(kwargs)
        else:
            kw = kwargs or self.kwargs

        return self.fun(*(self.pending + args), **kw)

class ForeignColumn:

    """
    Stores information about one record stored in a different table
    """
    
    def __init__(self, name, foreign_table, cascadeDelete = True):
        if name in RESERVED_WORDS:
            raise ReservedWord(name)
        self.name = name
        self.foreign_table = foreign_table

class OneToMany:

    """
    Stores information about records stored in a different table
    related to a certain record
    """

    def __init__(self, name, foreign_table):
        """

        """
        if name in RESERVED_WORDS:
            raise ReservedWord(name)
        self.name = name
        self.foreign_table = foreign_table

class Table:

    """
    A class to represent a database table
    """

    def __init__(self, connection, name, prefix, createOnInit = True):
        """

        """
        self.__verbose__ = False
        if name in RESERVED_WORDS:
            raise ReservedWord(name)
        if prefix in RESERVED_WORDS:
            raise ReservedWord(prefix)
        self.connection = connection
        self.name = name
        self.prefix = prefix
        self.columns = []
        self.foreign_columns = []
        self.oneToManyRelations = []
        self.manyToManyRelations = []
        self.indicies = []
        #self.recordset = {}
        self.recordCache = {}
        self.primary_keys = []
        self.dynamic_methods = {}
        self.dbtype = self.connection.__class__ == SQLiteConnection and conSQLite \
                      or self.connection.__class__ == MySQLConnection and conMySQL or None
        if self.tableInit() and self.columns and not self.tableExists(self.name) and createOnInit:
            self.createTable()

    def getRecordSet(self, where = None, limit = 1000):
        """Based on code found on ActiveState's Python cookbook"""
        sql = self.__buildSQLForRecordSet()
        if where:
            sql = sql + '\nWHERE %s' % where
        return self.connection.getRecordSet(sql)

    def getMTMTable(self, tableName):
        for mtm in self.manyToManyRelations:
            if mtm.name == tableName:
                return mtm
        return None

    def addIndex(self, name, columns, unique = False):
        """
        Adds an index to the database
        """
        assert type(name) == types.StringType, 'name must be a string'
        assert type(columns) in [types.TupleType, types.ListType], 'columns must be a tuple or list'
        self.indicies.append((name, columns))
        index_name = self.getIndexName(name)
        if not index_name in self.connection.getIndicies():
            self.connection.createIndex(
                self.name, 
                index_name, 
                ['%s_%s' % (self.prefix, column) for column in columns], 
                unique
            )

    def dropIndex(self, name):
        """
        Drops an index from the database
        """
        index_name = self.getIndexName(name)
        self.connection.dropIndex(index_name, self.name)

    def __addOTMEntry(self, data = {}, foreign_table = None):
        """

        """
        foreign_table.insert(data)

    def __updateOTMEntry(self, data = {}, foreign_table = None):
        """

        """
        foreign_table.update(data)

    def __removeOTMEntry(self, primaryKeys, foreign_table = None):
        """

        """
        assert type(primaryKeys) in [types.ListType, types.TupleType], 'primaryKeys must be supplied as tuple or list of integers'
        foreign_table.delete(primaryKeys)

    def addOneToManyRelation(self, name, foreign_table):
        """
        Adds a one-to-many-relation to the table
        """
        column = OneToMany(name.upper(), foreign_table)
        self.oneToManyRelations.append(column)
        new_func = curry(Table.__addOTMEntry, foreign_table=foreign_table)
        new_func.__doc__ = 'Inserts a link from a %s-table into a %s-table' % (self.name, foreign_table.name)
        setattr(self, 'insert%s' % (foreign_table.name.capitalize()), new.instancemethod(new_func, self, Table))
        new_func = curry(Table.__removeOTMEntry, foreign_table=foreign_table)
        new_func.__doc__ = 'Removes a %s-link from the %s-table' % (self.name, foreign_table.name)
        setattr(self, 'delete%s' % (foreign_table.name.capitalize()), new.instancemethod(new_func, self, Table))
        new_func = curry(Table.__updateOTMEntry, foreign_table=foreign_table)
        new_func.__doc__ = 'Updates a %s-link to the %s-table' % (self.name, foreign_table.name)
        setattr(self, 'update%s' % foreign_table.name.capitalize(), new.instancemethod(new_func, self, Table))

    def getSQLForTable(self):
        """
        Returns the SQL-statement used to create the table, if supported by the
        database in use.
        """
        return self.connection.getSQLForTable(self.name)

    def addForeignColumn(self, foreign_table, alternatePrefix = None, casecadeDelete = True):
        """

        """
        assert type(alternatePrefix) in [types.StringType, types.NoneType], 'alternatePrefix must be specified as None or a string'
        # TODO : check alternatePRefix for invalid characters, allow only a..z+1..0+_
        if alternatePrefix:
            alternatePrefix = alternatePrefix.upper()
            self.columns.append(IntegerColumn('%s_%s_ID' % (alternatePrefix, foreign_table.prefix)))
        else:
            self.columns.append(IntegerColumn('%s_ID' % foreign_table.prefix))
        self.foreign_columns.append((foreign_table, casecadeDelete, alternatePrefix))

    def buildCustomSQLForRecordSet(self, tables):
        columns = self.getFields()
        outer_join = []
        for fk_table, fk_casecadeDelete, fk_alternatePrefix in self.foreign_columns:
            # TODO : outer-join must be database-specific, generate statement from connection-class ????
            columns.extend(fk_table.getFields())
            outer_join.append('LEFT JOIN %s ON %s.%s_%s = %s.%s_ID' % (
                    fk_table.name,
                    self.name,
                    self.prefix,
                    '%s_ID' % fk_table.prefix,
                    fk_table.name,
                    fk_table.prefix
                    ))
        for table in tables:
            columns.extend(table.getFields())
            outer_join.append('LEFT JOIN %s ON %s.%s_%s = %s.%s_ID' % (table.name, self.name, self.prefix, '%s_ID' % table.prefix, table.name, table.prefix))
        columns.sort()
        sql = '''
        SELECT %s
        FROM %s
        %s
        ''' % (
            ', '.join(columns),
            self.name,
            '\n'.join(outer_join)
            )
        return sql
        
    def __buildSQLForRecordSet(self, includeForeignFields = True, insertTableName = True):
        """
        Returns a string-representation of the SQL-statement
        used to fetch all records in a table, including the
        foreign-keys it might reference to.
        """
        columns = self.getFields()
        outer_join = []
        if includeForeignFields:
            for fk_table, fk_casecadeDelete, fk_alternatePrefix in self.foreign_columns:
                # TODO : outer-join must be database-specific, generate statement from connection-class ????
                if not fk_alternatePrefix:
                    if insertTableName:
                        columns.extend(['%s.%s' % (fk_table.name, n) for n in fk_table.getFields()])
                    else:
                        columns.extend(fk_table.getFields())
                    outer_join.append('LEFT JOIN %s ON %s.%s_%s = %s.%s_ID' % (
                        fk_table.name,
                        self.name,
                        self.prefix,
                        '%s_ID' % fk_table.prefix,
                        fk_table.name,
                        fk_table.prefix
                        ))
                else:
                    for field in fk_table.getFields():
                        params = {
                            'fkt': fk_table.name,
                            'alp': fk_alternatePrefix,
                            'sbn': self.name,
                            'spx': self.prefix,
                            'fkp': fk_table.prefix,
                            'fn': field
                            }
                        columns.append('%(alp)s_%(fkt)s.%(fn)s as %(alp)s_%(fn)s' % params)
                    outer_join.append('LEFT JOIN %(fkt)s as %(alp)s_%(fkt)s ON %(sbn)s.%(spx)s_%(alp)s_%(fkp)s_ID = %(alp)s_%(fkt)s.%(fkp)s_ID' % params)
        sql = '''
        SELECT %s
        FROM %s
        %s
        ''' % (
            ','.join(columns),
            self.name,
            '\n'.join(outer_join)
            )
        return sql

    def getRecordWhere(self, where, includeForeignFields = True):
        """
        Gets a specific record by a where-statement.
        Also includes foreign columns, one-to-many and many-to-many-relationships
        """
        sql = self.__buildSQLForRecordSet(includeForeignFields) + '\nWHERE %s' % (where)
        result = self.connection.fetchOne(sql)
        if not result:
            raise Exception('NotFound')

        primaryKey = result['%s_ID' % self.prefix]

        for otm in self.oneToManyRelations:
            result['%s_%s' % (self.prefix, otm.name)] = otm.foreign_table.selectWhere(' %s_%s_ID = %s' % (otm.foreign_table.prefix, self.prefix, primaryKey))

        for mtm in self.manyToManyRelations:
            result['%s_%s' % (self.prefix, mtm.name.upper())] = mtm.getMTMRelations(primaryKey, self)

        return result

    def getRecord(self, primaryKey, includeForeignFields = True):
        """
        Gets a specific record by primary key. Includes also
        foreign columns, one-to-many- and many-to-many-relationships.
        """
        if not type(primaryKey) == types.IntType:
            try:
                primaryKey = int(primaryKey)
            except:
                pass
        assert type(primaryKey) == types.IntType, 'primaryKey must be an integer or value "convertable" to integer'
        sql = self.__buildSQLForRecordSet(includeForeignFields) + '\nWHERE %s_ID = %s' % (self.prefix, primaryKey)
        result = self.connection.fetchOne(sql)
        if not result:
            return #raise Exception('NotFound')

        for otm in self.oneToManyRelations:
            result['%s_%s' % (self.prefix, otm.name)] = otm.foreign_table.selectWhere(' %s_%s_ID = %s' % (otm.foreign_table.prefix, self.prefix, primaryKey))

        for mtm in self.manyToManyRelations:
            result['%s_%s' % (self.prefix, mtm.name.upper())] = mtm.getMTMRelations(primaryKey, self)

        return result

    def tableInit(self):
        """
        Override this method to add columns
        """
        return False

    def afterInit(self):
        """
        Override this method to ensure that
        something is run after the init of
        the subclass
        """
        pass

    def addColumn(self, column):
        """
        Adds a column to the table
        """
        self.columns.append(column)

    def getFields(self):
        """
        Returns a list of columns for this table.
        TODO : Should be re-factored to getColumns ???
        """
        fields = ['%s_%s' % (self.prefix, column.name) for column in self.columns if column.name != '%s_ID' % self.prefix]
        fields.insert(0, '%s_ID' % self.prefix)
        return fields

    def removeColumn(self, name):
        """
        Removes a column from the table.
        TODO : remove? 
        """
        for column in self.columns:
            if column.name == name:
                self.columns.remove(column)

    def beforeCreate(self):
        """
        Called before a table is created
        """
        pass

    def afterCreate(self):
        """
        Called after a table is created
        """
        pass

    def afterUpdate(self):
        """
        Called after a call to update
        """
        pass

    def afterDelete(self):
        """
        Called after a call to delete
        """
        pass

    def afterInsert(self):
        """
        Called after a call to insert
        """
        pass

    def beforeUpdate(self):
        """
        Called before a call to update
        """
        pass

    def beforeDelete(self):
        """
        Called before a call to delete
        """
        pass

    def beforeInsert(self):
        """
        Called before a call to insert
        """
        pass

    def tableExists(self, tableName):
        """
        Returns true if a table specificed by the tableName argument
        exists in the database
        """
        return self.connection.tableExists(tableName)

    def getIndexName(self, index):
        """

        """
        return 'IDX_%s_%s' % (self.name, index)

    def createTable(self, dropIfExists = False):
        """
        Creates the table in the database
        """
        self.beforeCreate()
        if dropIfExists and self.tableExists(self.name):
            self.dropTable()
        if self.tableExists(self.name):
            return
        create_smt = []
        if self.dbtype == conSQLite:
            create_smt.append('%s_ID INTEGER PRIMARY KEY' % self.prefix)
            for column in self.columns:
                create_smt.append(column.create(self.prefix, conSQLite))
        elif self.dbtype == conMySQL:
            create_smt.append('%s_ID INT PRIMARY KEY AUTO_INCREMENT' % self.prefix)
            for column in self.columns:
                create_smt.append(column.create(self.prefix, conMySQL))
        else:
            raise NotSupported("No supported connection was found")
        try:
            #self.runSql('CREATE %s TABLE %s (\n\t%s\n);' % (self.dbtype == conMySQL and 'IF NOT EXISTS' or '', self.name, ',\n\t'.join(create_smt)))
            sql = 'CREATE TABLE %s (\n\t%s\n);' % (self.name, ',\n\t'.join(create_smt))
            if self.__verbose__:
                print sql
            self.runSql(sql)
        except Exception, e:
            print 'CREATE FAILED: %s' % e
        self.afterCreate()

    def commit(self):
        """
        Calls the COMMIT-procedure and ends any active
        transactions if the database used supportes it.
        """
        self.connection.commit()

    def dropTable(self):
        """
        Drops the table from the database
        """
        if not self.tableExists(self.name):
            return
        try:
            self.runSql('drop table %s' % self.name)
        except Exception, e:
            print "dropTable failed: %s" % e

    def getCountWhere(self, where, groupBy = None):
        """

        """
        result = self.selectSql(
            '''
            select count(*) as RecCount
            from %s
            where %s
            %s
            ''' % (self.name, where, groupBy and '\nGROUP BY %s' % groupBy or '')
            )
        return result[0]['RecCount']

    def select(self, primaryKeys, orderBy = None, includeForeignFields = True):
        """

        """
        assert type(primaryKeys) in [types.TupleType, types.ListType], 'primaryKeys must be list or tuple of integers'
        sql = self.__buildSQLForRecordSet(includeForeignFields)
        sql = sql + '''
        WHERE %s_ID in (%s)
        %s
        ''' % (self.prefix, ','.join(map(str, primaryKeys)), orderBy and 'order by %s' % orderBy or '')
        result = self.connection.fetchAll(sql, {})
        return result

    def selectPlain(self, orderBy = None, count = None, includeForeignFields = True):
        """

        """
        if count:
            return self.connection.fetchMany(
                '%s%s' % (
                    self.__buildSQLForRecordSet(includeForeignFields),
                    orderBy and '\nORDER BY %s' % orderBy or ''),
                {},
                count
                )
        else:
            return self.connection.fetchAll(
                '%s%s' % (
                    self.__buildSQLForRecordSet(),
                    orderBy and '\nORDER BY %s' % orderBy or ''),
                {}
                )

    def selectWhere(self, where, orderBy = None, count = None, includeForeignFields = True):
        """

        """
        sql = self.__buildSQLForRecordSet(includeForeignFields)
        sql = sql + '''
        %s
        %s
        ''' % (where and '\nWHERE %s' % where or '', orderBy and 'order by %s' % orderBy or '')
        if count:
            return self.connection.fetchMany(sql, {}, count)
        else:
            return self.connection.fetchAll(sql, {})

    def selectSql(self, sql, params = {}, count = None):
        """

        """
        if count:
            return self.connection.fetchMany(sql, params, count)
        else:
            return self.connection.fetchAll(sql, params)

    def selectCustom(self, columns, where = '', orderBy = '', params = {}, count = None):
        """

        """
        assert type(columns) == types.TupleType, 'columns must be supplied as a tuple'
        assert type(count) in [types.NoneType, types.IntType], 'count must be a positive integer'
        assert type(params) == types.DictionaryType, 'params must be supplied as a dictionary'
        sql = 'select %s \nfrom %s \n%s \n%s' % (
            ','.join(columns),
            self.name,
            where and 'where %s' % where or '',
            orderBy and 'order by %s' % orderBy or ''
            )
        if count:
            return self.connection.fetchMany(sql, params, count)
        else:
            return self.connection.fetchAll(sql, params)

    def runSql(self, sql, params = {}):
        """

        """
        self.connection.execSql(sql, params)

    def delete(self, primaryKeys):
        """

        """
        assert type(primaryKeys) in [types.ListType, types.TupleType], 'primaryKeys must be supplied as list or tuple of integers'
        self.beforeDelete()
        self.runSql('delete from %s where %s_ID in (%s)' % (self.name, self.prefix, ','.join(map(str, primaryKeys))))
        self.commit()
        self.afterDelete()

    def deleteSql(self, sql):
        """

        """
        self.beforeDelete()
        self.runSql('delete from %s where %s' % (self.name, sql))
        self.commit()
        self.afterDelete()

    def deleteWhere(self, dict, anyValue = False):
        """

        """
        self.beforeDelete()
        assert(type(dict) == types.DictType, 'Values must be a dictionary')
        params = []
        for k,v in dict.items():
            if type(v) == types.BooleanType:
                params.append('%s = %s' % (k, v and 1 or 0))
            elif type(v) == types.StringType:
                params.append("%s = '%s'" % (k,v))
            elif type(v) == types.ListType:
                args = []
                for arg in v:
                    if type(arg) == types.StringType:
                        args.append("'%s'" % arg)
                    elif type(v) == types.BooleanType:
                        params.append('%s = %s' % (k, v and 1 or 0))
                    else:
                        args.append('%s' % arg)
                params.append("%s in (%s)" % (k, ','.join(args)))
            else:
                params.append('%s = %s' % (k,v))
        if anyValue:
            stmt = ' or '.join(params)
        else:
            stmt = ' and '.join(params)
        sql = 'delete from %s where %s' % (self.name, stmt)
        self.runSql(sql)
        self.commit()
        self.afterDelete()

    def insert(self, params):
        """

        """
        insert_sql = '''
        insert into %s
        (%s)
        values
        (%s)'''
        assert type(params) == types.DictionaryType, 'params must be supplied as a dictionary'
        self.beforeInsert()
        params = self.__filterParams(params)
        keys = params.keys()
        fields = ',\n'.join(keys)
        values = ',\n'.join(['%%(%s)s' % k for k in keys])
        self.runSql(insert_sql % (self.name, fields, values), params)
        self.afterInsert()
        PK = self.connection.fetchOne('select MAX(%s_ID) as PK from %s' % (self.prefix, self.name))['PK']
        if not PK:
            PK = 1
        return PK
        #return self.connection.fetchOne('select %s_ID from %s where %s_ID = %s' % (self.prefix, self.name, self.prefix, PK))

    def __filterParams(self, params):
        """

        """
        assert type(params) == types.DictionaryType, 'params must be supplied as a dictionary. Datatype : %s' % type(params)
        for k,v in params.items():
            if v == False:
                params[k] = 0
            elif v == True:
                params[k] = 1
        pl = len(self.prefix)
        result = {}
        for k in [k for k in params.keys() if k[0:pl] == self.prefix]:
            result[k] = params[k]
        return result

    def updateNull(self, params, exceptions = []):
        """
        Updates only NULL-values for a record
        """
        assert type(params) == types.DictionaryType, 'params must be supplied as a dictionary. Datatype : %s' % type(params)
        self.beforeUpdate()
        params = self.__filterParams(params)
        existing_record = self.getRecord(params['%s_ID' % self.prefix])
        if not existing_record:
            del params['%s_ID' % self.prefix]
            self.insert(params)
        else:
            existing_keys = self.__filterParams(existing_record)
            keys = []
            for k in existing_keys:
                if not existing_record[k] and params[k] or k in exceptions:
                    keys.append(k)
            sql = '''
            UPDATE %s SET
            %s
            WHERE %s_ID = %s
            ''' % (self.name, ',\n'.join(['%s=%%(%s)s' % (k,k) for k in keys]), self.prefix, params['%s_ID' % self.prefix])
            try:
                self.runSql(sql, params)
            except Exception, e:
                print sql % params
                raise e
            self.commit()
        self.afterUpdate()
        
    def updateWhere(self, params, where):
        """

        """
        assert type(params) == types.DictionaryType, 'params must be supplied as a dictionary'
        self.beforeUpdate()
        params = self.__filterParams(params)
        keys = params.keys()
        sql = '''
        UPDATE %s SET
        %s
        WHERE %s
        ''' % (self.name, ',\n'.join(['%s=%%(%s)s' % (k,k) for k in keys]), where)
        try:
            self.runSql(sql, params)
        except Exception, e:
            print sql % params
            raise e
        self.commit()
        self.afterUpdate()

    def update(self, params):
        """

        """
        assert params.has_key('%s_ID' % self.prefix), 'Update requires the primarykey of the record to update'
        self.beforeUpdate()
        params = self.__filterParams(params)
        keys = params.keys()
        fields = ',\n'.join(['%s=%%(%s)s' % (k,k) for k in keys])
        sql = '''
        update %s set
        %s
        where %s_ID = %s''' % (self.name, fields, self.prefix, params['%s_ID' % self.prefix])
        try:
            self.runSql(sql, params)
        except Exception, e:
            print sql % params
            raise e
        self.commit()
        self.afterUpdate()

    def exportData(self, folder):
        """

        """
        pass

    def importData(self, folder):
        """

        """
        pass

##    def loadrecset(self, where = None):
##        self.recordset = self.fetchAll(self.__buildSQLForEntireRecordSet())

##    def __getitem__(self, recno):
##        if not self.recordset:
##            print "No record-set"
##            raise NoRecordSet
##        result = self.getRecord(recno)
##        if not result:
##            raise NoResult
##        print "__GETITEM__", result
####        result = self.recordset[recno]
####        result.update(self.getForeignColumns(result))
####        result.update(self.getOneToMany(result['%s_ID' % self.prefix]))
####        result.update(self.getManyToManyRelationships(result['%s_ID' % self.prefix]))
##        return result

class ManyToManyTable(Table):

    """

    """

    def __init__(self, name, prefix, table1, table2, checkIntegrity = False, casecadeDelete = False):
        """

        """
        Table.__init__(self, table1.connection, name, prefix)
        self.table1 = table1
        self.table2 = table2
        self.checkIntegrity = checkIntegrity
        self.casecadeDelete = casecadeDelete
        self.addColumn(IntegerColumn('%s_ID' % (self.table1.prefix), notNull = True))
        self.addColumn(IntegerColumn('%s_ID' % (self.table2.prefix), notNull = True))
        self.table1.manyToManyRelations.append(self)
        self.table2.manyToManyRelations.append(self)
        self.tableInit()

        new_func = curry(ManyToManyTable.__addMTMRelation)
        setattr(self, 'add%s' % (self.name.capitalize()), new.instancemethod(new_func, self, ManyToManyTable))

        new_func = curry(ManyToManyTable.__updateMTMRelation)
        setattr(self, 'update%s' % (self.name.capitalize()), new.instancemethod(new_func, self, ManyToManyTable))

        new_func = curry(ManyToManyTable.__deleteMTMRelation)
        setattr(self, 'delete%s' % (self.name.capitalize()), new.instancemethod(new_func, self, ManyToManyTable))

    def __addMTMRelation(self, params):
        """

        """
        assert params.has_key('%s_%s_ID' % (self.prefix, self.table1.prefix)) \
               and params.has_key('%s_%s_ID' % (self.prefix, self.table2.prefix)), 'Params is missing primary-key for one of the tables in this many-to-many relationship'
        if self.checkIntegrity:
            count1 = self.table1.connection.fetchOne('select count(*) as C from %s where %s_ID = %s' % (self.table1.name, self.table1.prefix, params['%s_%s_ID' % (self.prefix, self.table1.prefix)]))
            count2 = self.table1.connection.fetchOne('select count(*) as C from %s where %s_ID = %s' % (self.table2.name, self.table2.prefix, params['%s_%s_ID' % (self.prefix, self.table2.prefix)]))
            if not count1 == 1 or not count2 == 1:
                raise IntegrityCheckFailed()
        if params.has_key('%s_ID' % self.prefix):
            del params['%s_ID' % self.prefix]
        self.insert(params)

    def __updateMTMRelation(self, params):
        """

        """
        assert params.has_key('%s_%s_ID' % (self.prefix, self.table1.prefix)), 'Params is missing primary-key for one of the tables in this many-to-many relationship'
        assert params.has_key('%s_%s_ID' % (self.prefix, self.table2.prefix)), 'Params is missing primary-key for one of the tables in this many-to-many relationship'
        assert params.has_key('%s_ID' % self.prefix), 'Missing primary-key for record to update'
        if self.checkIntegrity:
            count1 = self.table1.connection.fetchOne('select count(*) as C from %s where %s_ID = %s' % (self.table1.name, self.table1.prefix, params['%s_%s_ID' % (self.prefix, self.table1.prefix)]))['C']
            count2 = self.table1.connection.fetchOne('select count(*) as C from %s where %s_ID = %s' % (self.table2.name, self.table2.prefix, params['%s_%s_ID' % (self.prefix, self.table2.prefix)]))['C']
            if not int(count1) == 1 or not int(count2) == 1:
                raise IntegrityCheckFailed()
        self.update(params)

    def __deleteMTMRelation(self, primaryKeys):
        """

        """
        assert type(primaryKeys) in [types.ListType, types.TupleType], 'Primarykeys must be supplied as a list or tuple of integers'
        if self.casecadeDelete:
            raise NotImplemented()
        else:
            self.delete(primaryKeys)

    def __afterCreate(self):
        """

        """
        self.addIndex(self.table1.name, ['%s_ID' % self.table1.prefix])
        self.addIndex(self.table2.name, ['%s_ID' % self.table2.prefix])

    def getMTMRelations(self, primaryKey, table, where = None, orderBy = None):
        """

        """
        if where or orderBy:
            raise NotImplemented()

        columns = self.getFields()
        if table == self.table1:
            tb1 = self.table1
            columns.extend(self.table2.getFields())
        elif table == self.table2:
            tb1 = self.table2
            columns.extend(self.table1.getFields())
        else:
            raise TableNotPartOfRelation()

        sql = """
        select %s
        from %s, %s, %s
        where %s_ID = %s_%s_ID
        and %s_ID = %s_%s_ID
        and %s_ID = %s
        %s
        %s
        """ % (
            ','.join(columns),
            self.table1.name,
            self.table2.name,
            self.name,
            self.table1.prefix,
            self.prefix,
            self.table1.prefix,
            self.table2.prefix,
            self.prefix,
            self.table2.prefix,
            tb1.prefix,
            primaryKey,
            where and where or '',
            orderBy and orderBy or ''
            )
        return self.connection.fetchAll(sql)

class TreeTable(Table):
    """
    To quickly define tree-structures stored in relational databases ...
    """
    def __init__(self, connection, name, prefix, nameField = 'NAME', createOnInit = False):
        """

        """
        assert type(nameField) == types.StringType, 'nameField must be a string'
        Table.__init__(self, connection, name, prefix, createOnInit = False)
        self.__verbose__ = True
        self.addColumn(TextColumn(nameField.upper(), notNull = True))
        self.addColumn(IntegerColumn('PARENT_ID'))
        self.nameField = nameField.upper()
        if self.columns and not self.tableExists(self.name) and createOnInit:
            self.createTable()
        if self.tableExists(self.name):
            self.generateTree()
        else:
            self.tree = []

    def generateTree(self):
        """

        """

        class Tree:

            """

            """

            def __init__(self, nodes):
                self.nodes = nodes
                self.lookup = {}
                for node in nodes:
                    self.lookup[node.pid] = node

            def listElements(self, spacer = ','):
                return [(c.pid, p.path(spacer)) for c in self.nodes]

            def __getitem__(self, index):
                if index >= 0 and index > len(self.nodes):
                    raise IndexError
                return self.nodes[index]

            def getItem(self, pid):
                if type(pid) == types.StringType:
                    pid = int(pid)
                for node in self.nodes:
                    if node.pid == pid:
                        return node

        class Node:

            """

            """

            def __init__(self, name, pid, parent_id, data):
                self.name = name
                self.pid = pid
                self.parent_id = parent_id
                self.data = data
                self.__path = []
                self.__references = []

            def getReferences(self):
                return self.__references

            def path(self, spacer = ','):
                assert type(spacer) == types.StringType, 'Argument "spacer" must be a string'
                p = self.__path[:]
                p.reverse()
                result = []
                for path in p:
                    result.append(path)
                result.append(self.name)
                return spacer.join(result)

            def hasChildren(self):
                return len(self.__references) > 0

            def __cmp__(self, other):
                if self.path() < other.path():  # compare name value (should be unique)
                    return -1
                elif self.path() > other.path():
                    return 1
                else:
                    return 0

            def dig(self, parent_id, nodes):
                for node in nodes:
                    if node.pid == parent_id:
                        self.__path.append(node.name)
                        node.__references.append(self.pid)
                        if node.parent_id != '0' and node.parent_id != None:
                            nodes.remove(node)
                            self.dig(node.parent_id, nodes)

            def __repr__(self):
                return "*"*80 + """
NAME: %s
PID: %s
PARENT-ID:%s
PATH:%s
REFERENCES:%s
DATA:%s
""" % (self.name, self.pid, self.parent_id, self.path(), self.__references, self.data)

        nodes = []
        for c in self.selectPlain(orderBy = '%s_ID, %s_PARENT_ID' % (self.prefix, self.prefix)):
            nodes.append(Node(c['%s_%s' % (self.prefix, self.nameField)], c['%s_ID' % self.prefix], c['%s_PARENT_ID' % self.prefix], c))

        for node in nodes:
            if node.parent_id != '0' and node.parent_id != None:
                node.dig(node.parent_id, nodes[:])

        nodes.sort()
        self.tree = Tree(nodes)

    def addItem(self, name, parent_id = None, **kw):
        if parent_id and parent_id != 0:
            if not self.tree.getItem(parent_id):
                raise Exception('No parent-id found using specified key')
        params = kw
        params['%s_%s' % (self.prefix, self.nameField)] = name
        if parent_id:
            params['%s_PARENT_ID' % self.prefix] = parent_id
        self.insert(params)

    def getItem(self, pid):
        node = self.tree.getItem(pid)
        if not node:
            return {}
        result = node.data
        result['_HAS_CHILDREN_'] = node.hasChildren()
        if len(self.columns) > 2:
            result.update(self.getRecord(pid))
        return result

    def setItem(self, pid, parent_id, name, **kw):
        params = kw
        params.update(
            {
                '%s_ID' % self.prefix: pid,
                '%s_PARENT_ID' % self.prefix: parent_id,
                '%s_%s' % (self.prefix, self.nameField): name
                }
            )
        if not self.tree.lookup.has_key(pid):
            self.insert(params)
        else:
            self.update(params)

    def deleteItem(self, pid):
        node = self.tree.getItem(pid)
        PKS = [pid]
        PKS.extend(node.getReferences())
        self.delete(PKS)

    def getPaths(self, spacer = ','):
        result = []
        for node in self.tree:
            result.append((node.pid, node.path(spacer)))
        result.sort()
        return result

    def afterDelete(self):
        self.generateTree()

    def afterInsert(self):
        self.generateTree()

    def afterUpdate(self):
        self.generateTree()

    def getTree(self, spacer = '&nbsp;&raquo;&nbsp;'):
        categories = []
        for cid, cat_name in self.getPaths(spacer):
            cat = self.getItem(cid)
            cat['%s_PATH' % self.prefix] = cat_name
            categories.append(cat)
        return categories
