import unittest, os, copy
import pprint
from test import test_support
from hs.DBAbstraction import Connection, Table, Column
from hs.utils import compareDicts
from mx.DateTime import DateFrom

dbfile = 'testcase.db'

data1 = {
    'PRS_NAME': 'Thomas Weholt',
    'PRS_AGE': 29,
    'PRS_SALARY': 350.50,
    'PRS_ACTIVE': True,
    'PRS_EMPLOYEE_DATE': DateFrom("1999-05-01"),
    'PRS_CUS_ID': 1,
    'PRS_SOC_ID': 1,
    'PRS_SECOND_SOC_ID': 5,
    'PRS_THIRD_SOC_ID': 6
    }

data2 = {
    'PRS_NAME': 'Cecilie A Olsen',
    'PRS_AGE': 27,
    'PRS_SALARY': 250.50,
    'PRS_ACTIVE': True,
    'PRS_EMPLOYEE_DATE': DateFrom("2001-01-01"),
    'PRS_CUS_ID': None,
    'PRS_SOC_ID': None
    }

data3 = {
    'PRS_NAME': 'Tuva Weholt',
    'PRS_AGE': 1,
    'PRS_SALARY': 5.2,
    'PRS_ACTIVE': False,
    'PRS_EMPLOYEE_DATE': DateFrom("2002-01-01"),
    'PRS_CUS_ID': 2
    }

cus1 = {
    'CUS_TITLE': 'Fav guy'
    }

cus2 = {
    'CUS_TITLE': 'Coolest little girl'
    }

social_data = [
    {
        'SOC_SSN': '321543',
        'SOC_DEAD': False
        },
    {
        'SOC_SSN': '222222-2222',
        'SOC_DEAD': True
        },
    {
        'SOC_SSN': '101010101',
        'SOC_DEAD': False
        },
    {
        'SOC_SSN': '5345435',
        'SOC_DEAD': True
        },
    {
        'SOC_SSN': '666',
        'SOC_DEAD': False
        },
    {
        'SOC_SSN': '42',
        'SOC_DEAD': False
        }
    ]

orders = [
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Sony',
     'ORD_PRODUCT': '32" TV',
     'ORD_PROD_ID': 1,
     'ORD_PRS_ID': 1},
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Toshiba',
     'ORD_PRODUCT': 'DVD Player 850C',
     'ORD_PROD_ID': 2,
     'ORD_PRS_ID': 1},
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Sony',
     'ORD_PRODUCT': '32" TV',
     'ORD_PROD_ID': 1,
     'ORD_PRS_ID': 2},
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Sony',
     'ORD_PRODUCT': 'Surround Reciever 810x',
     'ORD_PROD_ID': 3,
     'ORD_PRS_ID': 1},
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Koda',
     'ORD_PRODUCT': 'Loud-speaker Surround set 120a',
     'ORD_PROD_ID': 4,
     'ORD_PRS_ID': 1},
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Acme',
     'ORD_PRODUCT': 'Huge Plastic Chicken',
     'ORD_PROD_ID': 5,
     'ORD_PRS_ID': 2},
    {'ORD_DATE': DateFrom('2000-01-01'),
     'ORD_SKU': '321-543543-KS',
     'ORD_MANUFACTOR': 'Sony',
     'ORD_PRODUCT': '32" TV',
     'ORD_PROD_ID': 2,
     'ORD_PRS_ID': 2},
    ]

feed_subscriptions = [
    {
        'FEED_URL': 'http://www.freshmeat.net/backend',
        'FEED_TITLE': 'Freshmeat'
        },
    {
        'FEED_URL': 'http://www.slashdot.org/backend',
        'FEED_TITLE': 'Slashdot'
        },
    {
        'FEED_URL': 'http://www.oreilly.net/rss.xml',
        'FEED_TITLE': "O'Reily"
        }
    ]

class TestBasicTableOperations(unittest.TestCase):

    def setUp(self):
        self.conn = Connection.SQLiteConnection(dbfile)
        #self.conn = Connection.MySQLConnection('test', 'localhost')
        #Customer-table
        self.cusTable = Table.Table(self.conn, 'customer', 'CUS')
        self.cusTable.addColumn(Column.TextColumn('title'))
        self.cusTable.createTable(dropIfExists = True)

        #Orders-table
        self.ordTable = Table.Table(self.conn, 'customerOrder', 'ORD')
        self.ordTable.addColumn(Column.TextColumn('SKU'))
        self.ordTable.addColumn(Column.TextColumn('MANUFACTOR'))
        self.ordTable.addColumn(Column.TextColumn('Product'))
        self.ordTable.addColumn(Column.IntegerColumn('PROD_ID'))
        self.ordTable.addColumn(Column.IntegerColumn('PRS_ID'))
        self.ordTable.addColumn(Column.DateColumn('DATE'))
        self.ordTable.createTable(dropIfExists = True)

        #Social-security-record ( for lack of a better example ... )
        self.socTable = Table.Table(self.conn, 'social', 'SOC')
        self.socTable.addColumn(Column.TextColumn('SSN', maxLength = 10))
        self.socTable.addColumn(Column.BooleanColumn('DEAD'))
        self.socTable.createTable(dropIfExists = True)
        #Person-table
        self.dbtable = Table.Table(self.conn, 'person', 'PRS')
        self.dbtable.addColumn(Column.TextColumn('NAME', maxLength = 50, notNull = True))
        self.dbtable.addColumn(Column.IntegerColumn('AGE'))
        self.dbtable.addColumn(Column.FloatColumn('SALARY'))
        self.dbtable.addColumn(Column.BooleanColumn('ACTIVE'))
        self.dbtable.addColumn(Column.DateColumn('EMPLOYEE_DATE'))
        self.dbtable.addForeignColumn(self.cusTable)
        self.dbtable.addForeignColumn(self.socTable)
        self.dbtable.addForeignColumn(self.socTable, alternatePrefix = 'SECOND')
        self.dbtable.addForeignColumn(self.socTable, alternatePrefix = 'THIRD')
        self.dbtable.addOneToManyRelation('orders', self.ordTable)
        self.dbtable.createTable(dropIfExists = True)
        #NewsFeeds-table
        self.feedsTable = Table.Table(self.conn, 'newsfeed', 'FEED')
        self.feedsTable.addColumn(Column.TextColumn('URL', maxLength = 150, notNull = True))
        self.feedsTable.addColumn(Column.TextColumn('TITLE', maxLength = 150, notNull = True))
        self.feedsTable.createTable(dropIfExists = True)
        #Many-to-many-link from person to newsfeeds
        self.feedSubscriptionsTable = Table.ManyToManyTable('subscription', 'SUB', self.feedsTable, self.dbtable)
        self.feedSubscriptionsTable.addColumn(Column.DateColumn('REG_DATE'))
        self.feedSubscriptionsTable.addColumn(Column.BooleanColumn('ACTIVE'))
        self.feedSubscriptionsTable.createTable(dropIfExists = True)
        #pprint.pprint(dir(self.feedSubscriptionsTable))

        self.tree = Table.TreeTable(self.conn, 'category', 'CAT', 'NAME')
        self.tree.addColumn(Column.TextColumn('DESCRIPTION'))
        self.tree.createTable(dropIfExists = True)

    def tearDown(self):
        self.cusTable.dropTable()
        self.ordTable.dropTable()
        self.socTable.dropTable()
        self.dbtable.dropTable()
        self.feedsTable.dropTable()
        self.feedSubscriptionsTable.dropTable()
        self.conn.close()
        try:
            os.remove(dbfile)
        except:
            pass

    def testMTMInsert(self):
        self.insertData()
        self.feedSubscriptionsTable.addSubscription({'SUB_PRS_ID': 1, 'SUB_FEED_ID': 1})
        self.feedSubscriptionsTable.addSubscription({'SUB_PRS_ID': 1, 'SUB_FEED_ID': 2})
        #pprint.pprint(self.dbtable.getRecord(1))

    def testMTMInsertBadData(self):
        self.insertData()
        try:
            self.feedSubscriptionsTable.addSubscription({'SUB_PRS_ID': 1}) # Missing secondary PK
            self.assertRaises(ValueError)
        except:
            pass
        try:
            self.feedSubscriptionsTable.addSubscription({}) # Missing PKs completly
            self.assertRaises(ValueError)
        except:
            pass

    def testMTMSQL(self):
        self.insertData()
        self.feedSubscriptionsTable.addSubscription({'SUB_PRS_ID': 1, 'SUB_FEED_ID': 1})
        self.feedSubscriptionsTable.addSubscription({'SUB_PRS_ID': 1, 'SUB_FEED_ID': 2})
        #print self.feedSubscriptionsTable.getMTMRelations(1, self.dbtable)
        #print self.feedSubscriptionsTable.getMTMRelations(1, self.feedsTable)

    def testForeignColumn(self):
        self.insertData()
        data = {}
        data.update(data1)
        data.update(social_data[0])
        data['CUS_ID'] = 1
        data['PRS_ID'] = 1
        data['SOC_ID'] = 1
        data.update(cus1)
        data['PRS_ORDERS'] = [orders[0], orders[1], orders[3], orders[4]]
        selected_data = self.dbtable.getRecord(1)
        #self.assert_(compareDicts(data, selected_data), 'Data stored is not equal to data selected')

    def testOTMRelationInsert(self):
        self.insertData()
        data = {
            'ORD_DATE': DateFrom('2004-05-01'),
            'ORD_SKU': '9043293-342-432',
            'ORD_MANUFACTOR': 'InFocus',
            'ORD_PRODUCT': 'DLP Projector 120ldb',
            'ORD_PROD_ID': 60,
            'ORD_PRS_ID': 1,
            }
        self.dbtable.insertCustomerorder(data)
        selected_data = self.dbtable.getRecord(1)
        self.assertEqual(len(selected_data['PRS_ORDERS']), 5)

    def testOTMRelationDelete(self):
        self.insertData()
        self.dbtable.deleteCustomerorder(primaryKeys = (1,))
        selected_data = self.dbtable.getRecord(1)
        self.assertEqual(len(selected_data['PRS_ORDERS']), 3)

    def testOTMRelationUpdate(self):
        self.insertData()
        data = self.dbtable.getRecord(1)['PRS_ORDERS'][0]
        new_data = {'ORD_ID': 1, 'ORD_MANUFACTOR': 'Sony Inc'}
        data.update(new_data)
        self.dbtable.updateCustomerorder(new_data)
        updated_data = self.dbtable.getRecord(1)['PRS_ORDERS'][0]
        self.assert_(compareDicts(data, updated_data), 'Data not updated with speficied data')

    def testUpdateWhere(self):
        self.insertData()
        self.ordTable.updateWhere({'ORD_PRS_ID': 2}, 'ORD_PRS_ID = 1')
        selected_data = self.dbtable.getRecord(1)
        self.assertEqual(len(selected_data['PRS_ORDERS']), 0)

    def testSimpleInserts(self):
        data = copy.copy(data1)
        pk = self.dbtable.insert(data)
## Disabled until further notice
##        print "PK", pk
##        fetched_data = self.dbtable.getRecord(int(pk))
##        data['PRS_ID'] = 1
##        print data, fetched_data
##        self.assertEqual(data, fetched_data)

    def testSimpleSelect(self):
        self.dbtable.insert(data1)
        selected_data = self.conn.fetchOne('select %s from %s where PRS_ID = 1' % (','.join(self.dbtable.getFields()), self.dbtable.name))
        data = copy.copy(data1)
        data['PRS_ID'] = 1
        self.assert_(compareDicts(data, selected_data), 'Data stored is not equal to data selected')

    def testSelectUsingSQL(self):
        self.insertData()
        selected_data = self.dbtable.selectSql('select PRS_ID, PRS_NAME from %s where PRS_ID in (1,2)' % (self.dbtable.name))
        self.assert_(len(selected_data) == 2, 'Data stored is not equal to data selected')

    def testSelectCustomSimple(self):
        self.insertData()
        selected_data = self.dbtable.selectCustom(('PRS_NAME', 'PRS_AGE'))
        self.assert_(len(selected_data) == 3 and len(selected_data[0].keys()) == 2, 'Data stored is not equal to data selected')

    def testSelectCustomWithOrderBy(self):
        self.insertData()
        selected_data = self.dbtable.selectCustom(('PRS_AGE',), orderBy = 'PRS_AGE DESC')
        self.assert_(selected_data == [{'PRS_AGE': 29}, {'PRS_AGE': 27}, {'PRS_AGE': 1}], 'Data stored is not equal to data selected')

    def testSelectCustomWithOrderByAndWhere(self):
        self.insertData()
        selected_data = self.dbtable.selectCustom(('PRS_AGE',), where = 'PRS_AGE > 26', orderBy = 'PRS_AGE DESC')
        self.assert_(selected_data == [{'PRS_AGE': 29}, {'PRS_AGE': 27}], 'Data stored is not equal to data selected')

    def testSimpleDelete(self):
        self.insertData()
        self.dbtable.delete([2])
        count = int(self.conn.fetchOne('select count(*) as C from %s' % self.dbtable.name)['C'])
        self.assertEqual(count, 2)

    def testOuterJoin(self):
        self.insertData()
        selected_data = self.dbtable.selectSql('''
        select PRS_NAME, CUS_TITLE from person
        LEFT JOIN customer ON person.PRS_CUS_ID = customer.CUS_ID
        ''')
        self.assertEqual(len(selected_data), 3)

    def insertData(self):
        for data in feed_subscriptions:
            self.feedsTable.insert(data)
        for data in orders:
            self.ordTable.insert(data)
        for data in social_data:
            self.socTable.insert(data)
        for data in [cus1, cus2]:
            self.cusTable.insert(data)
        for data in [data1, data2, data3]:
            self.dbtable.insert(data)

    def testDeleteWhere(self):
        self.insertData()
        self.dbtable.deleteWhere({'PRS_ACTIVE': True, 'PRS_AGE': 29})
        count = int(self.conn.fetchOne('select count(*) as C from %s' % self.dbtable.name)['C'])
        self.assertEqual(count, 2)

    def testCreateSimpleIndex(self):
        self.dbtable.addIndex('name', ['name'])
        self.assert_(len(self.conn.getIndicies()) == 1, 'Indexed was not created')

    def testDropIndex(self):
        self.dbtable.addIndex('name', ['name'])
        self.assert_(self.dbtable.getIndexName('name') in self.conn.getIndicies(), 'Indexed was not created so it could be dropped. Damn!! ;-)')
        self.dbtable.dropIndex('name')
        self.assert_(self.dbtable.getIndexName('name') not in self.conn.getIndicies(), 'Indexed was not dropped')

    def testUniqueIndex(self):
        self.dbtable.addIndex('name', ['name'], True)
        try:
            self.dbtable.insert({'PRS_NAME': 'ole'})
            self.dbtable.insert({'PRS_NAME': 'ole'})
            raise Exception('Unique index on column PRS_NAME failed')
        except:
            pass
##
    def testDeleteWhereUsingSql(self):
        self.insertData()
        self.dbtable.deleteSql('PRS_NAME like "%%Weholt%%" or PRS_AGE = 1')
        count = int(self.conn.fetchOne('select count(*) as C from %s' % self.dbtable.name)['C'])
        self.assertEqual(count, 1)

    def testDeleteWhereUsingInClause(self):
        self.insertData()
        self.dbtable.deleteWhere({'PRS_AGE': [29, 27]})
        count = int(self.conn.fetchOne('select count(*) as C from %s' % self.dbtable.name)['C'])
        self.assertEqual(count, 1)

    def testDeleteWhereUsingOr(self):
        self.insertData()
        self.dbtable.deleteWhere({'PRS_AGE': [29, 27], 'PRS_ID': 3}, anyValue = True)
        count = int(self.conn.fetchOne('select count(*) as C from %s' % self.dbtable.name)['C'])
        self.assertEqual(count, 0)

    def testMultiFK(self):
        self.insertData()
        pprint.pprint(self.dbtable.getRecord(1))
        

    def testUpdate(self):
        self.insertData()
        params = {'PRS_ACTIVE': False, 'PRS_AGE': 30, 'PRS_ID': 1}
        self.dbtable.update(params)
        data = copy.copy(data1)
        data['PRS_ID'] = 1
        data.update(params)
        selected_data = self.conn.fetchOne('select %s from %s where PRS_ID = 1' % (','.join(self.dbtable.getFields()), self.dbtable.name))
        self.assertEqual(data, selected_data)

        #self.assert_
        #self.assertRaises(ValueError, random.sample, self.seq, 20)

    def testHieracial(self):
        for data in [
            {'CAT_PARENT_ID': None, 'CAT_NAME': 'General'},
            {'CAT_PARENT_ID': 1, 'CAT_NAME': 'Info'},
            {'CAT_PARENT_ID': 1, 'CAT_NAME': 'Technical'},
            {'CAT_PARENT_ID': 3, 'CAT_NAME': 'Programming language'},
            {'CAT_PARENT_ID': 3, 'CAT_NAME': 'Concept'},
            {'CAT_PARENT_ID': None, 'CAT_NAME': 'Personal'},
            {'CAT_PARENT_ID': 6, 'CAT_NAME': 'Projects'},
            {'CAT_PARENT_ID': 6, 'CAT_NAME': 'Interests'},
            ]:
            self.tree.insert(data)
        self.tree.setItem(3, 1, 'Tech', CAT_DESCRIPTION = 'Something, something ...')
        pprint.pprint(self.tree.selectPlain(orderBy = 'CAT_ID, CAT_PARENT_ID'))
        for node in self.tree.tree:
            print node
        #self.tree.deleteItem(3)
        
        for node in self.tree.tree:
            print node
        print "1: -->", self.tree.getItem(2)
        print "2: -->", self.tree.getItem(3)
        self.tree.setItem(10, None, 'Blog')
        self.tree.setItem(11, 10, 'Rants')
        self.tree.setItem(5, 3, 'Conceptual')
        pprint.pprint(self.tree.getPaths(' / '))


def main():
    test_support.run_unittest(TestBasicTableOperations)

if __name__ == "__main__":
    main()

