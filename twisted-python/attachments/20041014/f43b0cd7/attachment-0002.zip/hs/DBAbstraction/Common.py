
SQLITE_SUPPORT = False
try:
    import sqlite
    SQLITE_SUPPORT = True
except ImportError:
    print "No SQLite-support."

MYSQL_SUPPORT = False
try:
    import MySQLdb
    MYSQL_SUPPORT = True
except ImportError:
    print "No MySQL-support."

# Constants :
conSQLite = 1
conMySQL  = 2

# Exceptions:
class NotSupported(Exception): pass
class NoRecordSet(Exception): pass
class ReservedWord(Exception):pass
class NotImplemented(Exception):pass
class NoResult(Exception):pass
class PrimaryKeyRequired(Exception): pass
class IntegrityCheckFailed(Exception): pass
class TableNotPartOfRelation(Exception): pass

RESERVED_WORDS = [
    'group',
    'where',
    'type',
    'select',
    'from',
    'order',
    'by',
    'delete',
    'insert',
    'update',
    'date',
    'integer',
    'varchar',
    'char',
    'float',
    'timestamp'
    ]
