import types
import new
from Common import *

class IColumn:

    """

    """

    def __init__(self, name, notNull = False, defaultValue = None, unique = False):
        """

        """
        if name in RESERVED_WORDS:
            raise ReservedWord(name)
        self.name = name.upper()
        self.notNull = notNull
        self.defaultValue = defaultValue
        self.unique = unique

    def __str__(self):
        """

        """
        return '<Column: %s, type: %s>' % (self.name, self.__class__.__name__)

    def __repr__(self):
        """

        """
        return self.__str__()

    def create(self, prefix, dbtype):
        """

        """
        prefix = None
        dbtype = None
        raise Exception('Override this method in your column-class')

    def uniqueColumn(self, dbtype):
        """

        """
        if not self.unique:
            return ''
        if dbtype in [conSQLite, conMySQL]:
            return ' UNIQUE'
        else:
            raise NotSupported()

    def notNullColumn(self, dbtype):
        """

        """
        if not self.notNull:
            return ''
        if dbtype in [conSQLite, conMySQL]:
            return ' NOT NULL'
        else:
            raise NotSupported()

class TextColumn(IColumn):

    """

    """

    def __init__(self, name, minLength = None, maxLength = None, fixedSize = False, defaultValue = None, notNull = False, unique = False):
        """

        """
        IColumn.__init__(self, name, notNull, defaultValue, unique)
        if fixedSize and not maxLength:
            raise Exception('Must specify length for fixed_length fields')
        self.minLength = minLength
        self.maxLength = maxLength
        self.fixedSize = fixedSize

    def create(self, prefix, dbtype):
        """

        """
        if dbtype in [conSQLite, conMySQL]:
            if self.fixedSize:
                return '%s_%s CHAR(%s)%s%s' % (prefix, self.name, self.maxLength, self.notNullColumn(dbtype), self.uniqueColumn(dbtype))
            elif self.maxLength:
                return '%s_%s VARCHAR(%s)%s%s' % (prefix, self.name, self.maxLength, self.notNullColumn(dbtype), self.uniqueColumn(dbtype))
            else:
                return '%s_%s TEXT%s%s' % (prefix, self.name, self.notNullColumn(dbtype), self.uniqueColumn(dbtype))
        else:
            raise NotSupported()

class IntegerColumn(IColumn):

    """

    """

    def __init__(self, name, size = 32, defaultValue = None, notNull = False, unique = False):
        """

        """
        IColumn.__init__(self, name, notNull, defaultValue, unique)
        self.size = size

    def create(self, prefix, dbtype):
        """

        """
        if dbtype in [conSQLite, conMySQL]:
            return '%s_%s INTEGER%s%s' % (prefix, self.name, self.notNullColumn(dbtype), self.uniqueColumn(dbtype))
        else:
            raise NotSupported()

class FloatColumn(IColumn):

    """

    """

    def __init__(self, name, size = 32, defaultValue = None, notNull = False, unique = False):
        """

        """
        IColumn.__init__(self, name, notNull, defaultValue, unique)
        self.size = size

    def create(self, prefix, dbtype):
        """

        """
        if dbtype in [conSQLite, conMySQL]:
            return '%s_%s FLOAT%s%s' % (prefix, self.name, self.notNullColumn(dbtype), self.uniqueColumn(dbtype))
        else:
            raise NotSupported()

class BooleanColumn(IColumn):

    """

    """

    def __init__(self, name, defaultValue = None, unique = False):
        """

        """
        IColumn.__init__(self, name, defaultValue, unique)

    def create(self, prefix, dbtype):
        """

        """
        if dbtype in [conSQLite, conMySQL]:
            return '%s_%s INTEGER%s%s' % (prefix, self.name, self.notNullColumn(dbtype), self.uniqueColumn(dbtype))
        else:
            raise NotSupported()

class DateTimeColumn(IColumn):

    """

    """

    def __init__(self, name, defaultValue = None):
        """

        """
        IColumn.__init__(self, name, defaultValue)

    def create(self, prefix, dbtype):
        """

        """
        if dbtype in [conSQLite, conMySQL]:
            return '%s_%s DATETIME%s' % (prefix, self.name, self.notNullColumn(dbtype))
        else:
            raise NotSupported()

class DateColumn(IColumn):

    """

    """

    def __init__(self, name, defaultValue = None):
        """

        """
        IColumn.__init__(self, name, defaultValue)

    def create(self, prefix, dbtype):
        """

        """
        if dbtype in [conSQLite,conMySQL]:
            return '%s_%s DATE%s' % (prefix, self.name, self.notNullColumn(dbtype))
        else:
            raise NotSupported()