DBAbstraction README

Author   : Thomas Weholt
Homepage : www.weholt.org
Email    : 2002@weholt.org
License  : same as python itself
Version  : 0.0.0.1

Features
========

- All tables are defined using python objects, no SQL at all
- All inserts and updates are done using dictionaries
- TODO ...

Why?
====

Why another database-abstraction layer for python? We allready got
SQLObject and a bunch of other solutions. Well, I need to handle
input and output from the data-layer as dictionaries. I mostly
do web-stuff and I allready got a bit of Form-handling code that
parse posted data into a dictionary. Populating that same Form is
also done using a dictionary so adding and updating data using
a web-page is a trivial task using these two packages together.

Requirements
============

* Python 2.3 ?? Only tested on Windows and Python 2.3 so far.
* SQLite, www.sqlite.org
* PySQLite-module, pysqlite.sourceforge.net
* the mxDateTime-module.
* MySQL and the python-module if you decide to go "heavy" instead of lite

About
=====

Each field in a table in this module must have a prefix. Let's say
you want to define a table "book" for storing information about books you'll
come up with a good prefix for that, for instance BK. So every field
would look like BK_TITLE, BK_AUTHOR, BK_ISBN etc.

An example :

from hs.DBAbstraction import Connection, Table, Column

conn = Connection.SQLiteConnection('mydb.db')

class Book(Table.Table):
    
    def __init__(self, conn):
        Table.Table.__init__(self, conn, 'book', 'BK')

    def tableInit(self):
        self.addColumn(Column.TextColumn('TITLE', maxLength = 100))
        self.addColumn(Column.TextColumn('AUTHOR', maxLength = 100))
        self.addColumn(Column.TextColumn('ISBN', maxLength = 50))

bookdb = Book(conn)
bookdb.createTable()

# To add a book
data = {
    'BK_TITLE': 'Programming Python',
    'BK_AUTHOR': 'Mark Lutz',
    'BK_ISBN': ''
    }

bookdb.insert(data)

# to select added books:

for book in bookdb.selectPlain(orderBy='BK_TITLE'):
    print book

# will print :
#{'BK_TITLE': 'Programming Python', 'BK_ID': 1, 'BK_AUTHOR': 'Mark Lutz', 'BK_ISBN': ''}

# to update :
bookdb.update({'BK_ID': 1, 'BK_ISBN': '123456-123456'})

# to delete :
bookdb.delete([1]) # delete takes a list of ids to delete

print "Books:", bookdb.selectPlain(orderBy='BK_TITLE')

You can define foreign-keys, indicies etc. as well.




Problems, wishes and whatnot
============================

I'd really like to get feedback on this, to support more databases, mainly
MS SQL and Postgresql. Another thing even higher on my priorites are to get it
more Twisted friendly, or at least somewhat Twisted compatible. Now it locks the entire
database and that sucks when using it in a non-threaded environment. For quick queries
and most operations it's fast enough. I'd preferr to write a Twisted-version of the
IConnection objects, probably one for all the subclasses of IConnection as well, but
I don't want to make it usable in Twisted only. Any help in this area would be great.
Any comment on improvements etc are also highly welcome.

Best regards,
Thomas Weholt
14. Oct 2004

