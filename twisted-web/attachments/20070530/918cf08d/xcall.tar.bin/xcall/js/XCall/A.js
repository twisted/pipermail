
// import XCall.B

XCall.A = Nevow.Athena.Widget.subclass ( 'XCall.A' );

XCall.A.methods (

		 function __init__ ( self, node )
		 {
		   XCall.A.upcall ( self, '__init__', node );
		 },

		 function handler ( self, node )
		 {
		   // Uncomment this to see that handler() is really being called.
		   // alert ( "Handler called" );

		   // This doesn't work.
		   XCall.B.chain ( "foo" );

		   // ... but this does work.
		   // XCall.B.prototype.chain ( "foo" );
		 }
		 );
