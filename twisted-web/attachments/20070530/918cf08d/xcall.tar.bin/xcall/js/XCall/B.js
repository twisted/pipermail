
XCall.B = Nevow.Athena.Widget.subclass ( 'XCall.B' );

XCall.B.methods (

		 function __init__ ( self, node )
		 {
		   XCall.B.upcall ( self, '__init__', node );
		 },

		 function chain ( self, arg )
		 {
		   alert ( "XCall.B.chain called: " + arg  );
		 }
		 );
