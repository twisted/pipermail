from twisted.python.filepath import FilePath

from nevow import athena
from nevow import loaders
from nevow import static
from nevow import tags as T

class XCallA ( athena.LiveElement ):
    jsClass = u'XCall.A'

    _js = athena.handler ( event = 'onclick', handler = 'handler' )

    docFactory = loaders.stan (
        T.div ( render = T.directive ( 'liveElement' ) ) [
            T.a ( href = '#' ) [ "Click Me A", _js ]
              ] )

class XCallB ( athena.LiveElement ):
    jsClass = u'XCall.B'

    _js = athena.handler ( event = 'onclick', handler = 'handler' )

    docFactory = loaders.stan (
        T.div ( render = T.directive ( 'liveElement' ) ) [
            T.p [ "Just some text" ]
              ] )


class XCallPage ( athena.LivePage ):
    docFactory = loaders.stan ( [
        T.html [ T.head ( render = T.directive ( "liveglue" ) ) ],
        T.body [
            T.div ( render = T.directive ( "xcalla" ) ),
            T.div ( render = T.directive ( "xcallb" ) )
        ]
    ] )

    def render_xcalla ( self, request, tag ):
        elem = XCallA()
        elem.setFragmentParent ( self )
        return elem

    def render_xcallb ( self, request, tag ):
        elem = XCallB()
        elem.setFragmentParent ( self )
        return elem

    def _file ( what ):
        _path = FilePath ( __file__ ).sibling ( what ).path
        return static.File ( _path )

    children = {
        'js'    : _file ( 'js' )
    }

from twisted.application import service, internet
from nevow               import appserver

application = service.Application ( "XCallPage" )
xCallPage   = XCallPage()
site        = appserver.NevowSite ( xCallPage )
webService  = internet.TCPServer ( 7777, site )
webService.setServiceParent ( application )
