from twisted.python import filepath
from nevow import athena

import xcall

jspath = athena.AutoJSPackage (
       filepath.FilePath ( xcall.__file__).parent().child ( 'js' ).path )
