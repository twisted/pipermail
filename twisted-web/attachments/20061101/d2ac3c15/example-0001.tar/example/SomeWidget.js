// import Nevow.Athena
// import Divmod

WebApp.SomeWidget = Nevow.Athena.Widget.subclass ( 'WebApp.SomeWidget' );

WebApp.SomeWidget.methods (

    function __init__ ( self, node )
    {
      WebApp.SomeWidget.upcall ( self, '__init__', node );
      self.inputNode  = self.firstNodeByAttribute ( 'class', 'sw-input' );
      self.outputNode = self.firstNodeByAttribute ( 'class', 'sw-output' );
    },

    function keyPressed ( self, node, event )
    {
      // Nicked from other example code.
      if ( event.keyCode < 32 )
        {
          return;
        }
        if ( event.keyCode >= 33 && event.keyCode <= 46 )
          {
            return;
          }
        if ( event.keyCode >= 112 && event.keyCode <= 123 )
          {
            return;
          }

      self.callRemote ( 'keyPressed', self.inputNode.value );
      return false;
    },
    
    function setOutput ( self, text )
    {
      self.outputNode.innerHTML = text;
      return false;
    }
);
