
from nevow import athena
from nevow import stan
from nevow import loaders
from nevow import tags as T
from nevow import flat

class SomeWidget ( athena.LiveElement ):

    jsClass = u'WebApp.SomeWidget'

    _js = (
        "Nevow.Athena.Widget.get(this).keyPressed(this, event); " +
        "return false;"
    )

    _handler = athena.handler (
        event = 'onkeyup', handler = 'keyPressed'
    )

    docFactoryJS = loaders.stan (
        T.div (
            render = T.directive ( 'liveElement' ),
            ) [
                "Some Widget",
                T.input (
                    type = "text",
                    _class = "sw-input",
                    onkeyup = _js,
                    ),
                T.div ( _class = "sw-output" ) [ "This gets overwritten" ],
            ]
    )

    docFactoryAthena = loaders.stan (
        T.div (
            render = T.directive ( 'liveElement' ),
            ) [
                "Some Widget",
                T.input (
                    type = "text",
                    _class = "sw-input",
                    ) [ _handler ],
                T.div ( _class = "sw-output" ) [ "This gets overwritten" ],
            ]
    )

    docFactory = docFactoryAthena
    
    def keyPressed ( self, input ):
        print "In keyPressed(): ", input
        self.callRemote ( "setOutput", input )
    athena.expose ( keyPressed )

        
class WebApp ( athena.LivePage ):

    DOCTYPE_XHTML = (
        '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" '
        '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
    )
    
    docFactory = loaders.stan (
        [
            T.xml ( DOCTYPE_XHTML ),
            T.html [ T.head ( render = T.directive ( "liveglue" ) ),
                     T.body ( render = T.directive ( "stuff" ) ),
                   ]
        ]
    )
    
    addSlash = True

    def __init__ ( self, *args, **kwargs ):
        super ( WebApp, self ).__init__ ( *args, **kwargs )
        self.jsModules.mapping.update ( {
            u'WebApp' : 'SomeWidget.js',
        } )


    def render_stuff ( self, ctx, data ):
        elem = SomeWidget()
        elem.setFragmentParent ( self )
        return elem


######################################################################
# Boilerplate start code for WebApp.
######################################################################

from twisted.application import service, internet
from nevow import appserver

res         = WebApp()
site        = appserver.NevowSite ( res )
application = service.Application ( "WebApp" )
webService  = internet.TCPServer ( 8080, site )
webService.setServiceParent ( application )

